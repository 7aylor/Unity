﻿namespace TwitchLib_API_Tester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.button28 = new System.Windows.Forms.Button();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.button29 = new System.Windows.Forms.Button();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.button30 = new System.Windows.Forms.Button();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.button37 = new System.Windows.Forms.Button();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.button36 = new System.Windows.Forms.Button();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.button35 = new System.Windows.Forms.Button();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.button34 = new System.Windows.Forms.Button();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button42 = new System.Windows.Forms.Button();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.button39 = new System.Windows.Forms.Button();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.button38 = new System.Windows.Forms.Button();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.button44 = new System.Windows.Forms.Button();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.button43 = new System.Windows.Forms.Button();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.button49 = new System.Windows.Forms.Button();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.button48 = new System.Windows.Forms.Button();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.button47 = new System.Windows.Forms.Button();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.button45 = new System.Windows.Forms.Button();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.button51 = new System.Windows.Forms.Button();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.button50 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.groupBox73 = new System.Windows.Forms.GroupBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.button74 = new System.Windows.Forms.Button();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.groupBox74 = new System.Windows.Forms.GroupBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.button75 = new System.Windows.Forms.Button();
            this.groupBox72 = new System.Windows.Forms.GroupBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.button73 = new System.Windows.Forms.Button();
            this.groupBox71 = new System.Windows.Forms.GroupBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.button72 = new System.Windows.Forms.Button();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.groupBox75 = new System.Windows.Forms.GroupBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.button76 = new System.Windows.Forms.Button();
            this.groupBox65 = new System.Windows.Forms.GroupBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.button64 = new System.Windows.Forms.Button();
            this.tabPage33 = new System.Windows.Forms.TabPage();
            this.tabPage34 = new System.Windows.Forms.TabPage();
            this.groupBox67 = new System.Windows.Forms.GroupBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.button66 = new System.Windows.Forms.Button();
            this.groupBox66 = new System.Windows.Forms.GroupBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.button65 = new System.Windows.Forms.Button();
            this.tabPage35 = new System.Windows.Forms.TabPage();
            this.groupBox55 = new System.Windows.Forms.GroupBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.button54 = new System.Windows.Forms.Button();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.button53 = new System.Windows.Forms.Button();
            this.tabPage36 = new System.Windows.Forms.TabPage();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.button22 = new System.Windows.Forms.Button();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.button21 = new System.Windows.Forms.Button();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.tabPage37 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage38 = new System.Windows.Forms.TabPage();
            this.groupBox82 = new System.Windows.Forms.GroupBox();
            this.button85 = new System.Windows.Forms.Button();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.groupBox81 = new System.Windows.Forms.GroupBox();
            this.button84 = new System.Windows.Forms.Button();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.groupBox80 = new System.Windows.Forms.GroupBox();
            this.button83 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.tabPage39 = new System.Windows.Forms.TabPage();
            this.groupBox86 = new System.Windows.Forms.GroupBox();
            this.button89 = new System.Windows.Forms.Button();
            this.tabPage40 = new System.Windows.Forms.TabPage();
            this.groupBox83 = new System.Windows.Forms.GroupBox();
            this.button86 = new System.Windows.Forms.Button();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.tabPage41 = new System.Windows.Forms.TabPage();
            this.groupBox84 = new System.Windows.Forms.GroupBox();
            this.button87 = new System.Windows.Forms.Button();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.tabPage42 = new System.Windows.Forms.TabPage();
            this.groupBox85 = new System.Windows.Forms.GroupBox();
            this.button88 = new System.Windows.Forms.Button();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.groupBox79 = new System.Windows.Forms.GroupBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.button81 = new System.Windows.Forms.Button();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.button80 = new System.Windows.Forms.Button();
            this.groupBox54 = new System.Windows.Forms.GroupBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.button52 = new System.Windows.Forms.Button();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.groupBox78 = new System.Windows.Forms.GroupBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.button79 = new System.Windows.Forms.Button();
            this.groupBox77 = new System.Windows.Forms.GroupBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.button78 = new System.Windows.Forms.Button();
            this.groupBox76 = new System.Windows.Forms.GroupBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.button77 = new System.Windows.Forms.Button();
            this.groupBox69 = new System.Windows.Forms.GroupBox();
            this.button69 = new System.Windows.Forms.Button();
            this.groupBox64 = new System.Windows.Forms.GroupBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.button63 = new System.Windows.Forms.Button();
            this.groupBox63 = new System.Windows.Forms.GroupBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.button62 = new System.Windows.Forms.Button();
            this.groupBox62 = new System.Windows.Forms.GroupBox();
            this.button61 = new System.Windows.Forms.Button();
            this.groupBox61 = new System.Windows.Forms.GroupBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.button60 = new System.Windows.Forms.Button();
            this.groupBox60 = new System.Windows.Forms.GroupBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.button59 = new System.Windows.Forms.Button();
            this.groupBox59 = new System.Windows.Forms.GroupBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.button58 = new System.Windows.Forms.Button();
            this.groupBox58 = new System.Windows.Forms.GroupBox();
            this.button57 = new System.Windows.Forms.Button();
            this.groupBox57 = new System.Windows.Forms.GroupBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.button55 = new System.Windows.Forms.Button();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.groupBox56 = new System.Windows.Forms.GroupBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.button56 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox70 = new System.Windows.Forms.GroupBox();
            this.button70 = new System.Windows.Forms.Button();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.button71 = new System.Windows.Forms.Button();
            this.groupBox68 = new System.Windows.Forms.GroupBox();
            this.button68 = new System.Windows.Forms.Button();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.button67 = new System.Windows.Forms.Button();
            this.tabPage43 = new System.Windows.Forms.TabPage();
            this.groupBox87 = new System.Windows.Forms.GroupBox();
            this.button90 = new System.Windows.Forms.Button();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.groupBox88 = new System.Windows.Forms.GroupBox();
            this.button91 = new System.Windows.Forms.Button();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.groupBox89 = new System.Windows.Forms.GroupBox();
            this.button92 = new System.Windows.Forms.Button();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.groupBox53.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.groupBox73.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.groupBox74.SuspendLayout();
            this.groupBox72.SuspendLayout();
            this.groupBox71.SuspendLayout();
            this.tabPage32.SuspendLayout();
            this.groupBox75.SuspendLayout();
            this.groupBox65.SuspendLayout();
            this.tabPage34.SuspendLayout();
            this.groupBox67.SuspendLayout();
            this.groupBox66.SuspendLayout();
            this.tabPage35.SuspendLayout();
            this.groupBox55.SuspendLayout();
            this.tabPage36.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage37.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage38.SuspendLayout();
            this.groupBox82.SuspendLayout();
            this.groupBox81.SuspendLayout();
            this.groupBox80.SuspendLayout();
            this.tabPage39.SuspendLayout();
            this.groupBox86.SuspendLayout();
            this.tabPage40.SuspendLayout();
            this.groupBox83.SuspendLayout();
            this.tabPage41.SuspendLayout();
            this.groupBox84.SuspendLayout();
            this.tabPage42.SuspendLayout();
            this.groupBox85.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.groupBox79.SuspendLayout();
            this.groupBox54.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.groupBox78.SuspendLayout();
            this.groupBox77.SuspendLayout();
            this.groupBox76.SuspendLayout();
            this.groupBox69.SuspendLayout();
            this.groupBox64.SuspendLayout();
            this.groupBox63.SuspendLayout();
            this.groupBox62.SuspendLayout();
            this.groupBox61.SuspendLayout();
            this.groupBox60.SuspendLayout();
            this.groupBox59.SuspendLayout();
            this.groupBox58.SuspendLayout();
            this.groupBox57.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.groupBox56.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox70.SuspendLayout();
            this.groupBox68.SuspendLayout();
            this.tabPage43.SuspendLayout();
            this.groupBox87.SuspendLayout();
            this.groupBox88.SuspendLayout();
            this.groupBox89.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Channel:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(187, 57);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(343, 38);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(187, 117);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(343, 38);
            this.textBox2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Client ID:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Controls.Add(this.tabPage15);
            this.tabControl1.Controls.Add(this.tabPage16);
            this.tabControl1.Controls.Add(this.tabPage17);
            this.tabControl1.Controls.Add(this.tabPage18);
            this.tabControl1.Location = new System.Drawing.Point(5, 7);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1531, 1035);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(10, 48);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1511, 977);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Blocks";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Location = new System.Drawing.Point(5, 351);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(437, 198);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Remove Block";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(120, 43);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(303, 38);
            this.textBox5.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 32);
            this.label4.TabIndex = 1;
            this.label4.Text = "Target:";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(5, 100);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(424, 81);
            this.button3.TabIndex = 0;
            this.button3.Text = "Send";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Location = new System.Drawing.Point(5, 148);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(437, 198);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Create Block";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(120, 43);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(303, 38);
            this.textBox4.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "Target:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(5, 100);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(424, 81);
            this.button2.TabIndex = 0;
            this.button2.Text = "Send";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Location = new System.Drawing.Point(5, 7);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(437, 136);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Get Blocks";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(5, 38);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(424, 81);
            this.button1.TabIndex = 0;
            this.button1.Text = "Fetch";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox11);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(10, 48);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1511, 977);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Channel Feed";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.textBox11);
            this.groupBox11.Controls.Add(this.label12);
            this.groupBox11.Controls.Add(this.textBox12);
            this.groupBox11.Controls.Add(this.label13);
            this.groupBox11.Controls.Add(this.button9);
            this.groupBox11.Location = new System.Drawing.Point(459, 262);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Size = new System.Drawing.Size(437, 250);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Remove Reaction";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(149, 98);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(265, 38);
            this.textBox11.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 32);
            this.label12.TabIndex = 4;
            this.label12.Text = "Emote Id:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(128, 41);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(284, 38);
            this.textBox12.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 32);
            this.label13.TabIndex = 1;
            this.label13.Text = "Post ID: ";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(5, 153);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(424, 81);
            this.button9.TabIndex = 0;
            this.button9.Text = "Fetch";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox10);
            this.groupBox10.Controls.Add(this.label11);
            this.groupBox10.Controls.Add(this.textBox9);
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.button8);
            this.groupBox10.Location = new System.Drawing.Point(459, 7);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Size = new System.Drawing.Size(437, 250);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Create Reaction";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(149, 98);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(265, 38);
            this.textBox10.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 100);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(135, 32);
            this.label11.TabIndex = 4;
            this.label11.Text = "Emote Id:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(128, 41);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(284, 38);
            this.textBox9.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 32);
            this.label10.TabIndex = 1;
            this.label10.Text = "Post ID: ";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(5, 153);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(424, 81);
            this.button8.TabIndex = 0;
            this.button8.Text = "Fetch";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBox8);
            this.groupBox9.Controls.Add(this.label9);
            this.groupBox9.Controls.Add(this.button7);
            this.groupBox9.Location = new System.Drawing.Point(5, 610);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Size = new System.Drawing.Size(437, 198);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Delete Post";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(128, 41);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(284, 38);
            this.textBox8.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 32);
            this.label9.TabIndex = 1;
            this.label9.Text = "Post ID: ";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(5, 98);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(424, 81);
            this.button7.TabIndex = 0;
            this.button7.Text = "Fetch";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox7);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.button6);
            this.groupBox8.Location = new System.Drawing.Point(5, 408);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox8.Size = new System.Drawing.Size(437, 198);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Get Post By Id";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(128, 41);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(284, 38);
            this.textBox7.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 32);
            this.label8.TabIndex = 1;
            this.label8.Text = "Post ID: ";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(5, 98);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(424, 81);
            this.button6.TabIndex = 0;
            this.button6.Text = "Fetch";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.richTextBox2);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Controls.Add(this.button5);
            this.groupBox7.Location = new System.Drawing.Point(5, 148);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(437, 255);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Get Channel Feed Posts";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(136, 38);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(279, 97);
            this.richTextBox2.TabIndex = 3;
            this.richTextBox2.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 32);
            this.label7.TabIndex = 1;
            this.label7.Text = "Content:";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(5, 150);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(424, 81);
            this.button5.TabIndex = 0;
            this.button5.Text = "Fetch";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button4);
            this.groupBox6.Location = new System.Drawing.Point(5, 7);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Size = new System.Drawing.Size(437, 136);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Get Channel Feed Posts";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(5, 38);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(424, 81);
            this.button4.TabIndex = 0;
            this.button4.Text = "Fetch";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox18);
            this.tabPage6.Controls.Add(this.groupBox17);
            this.tabPage6.Controls.Add(this.groupBox16);
            this.tabPage6.Controls.Add(this.groupBox15);
            this.tabPage6.Controls.Add(this.groupBox14);
            this.tabPage6.Controls.Add(this.groupBox13);
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Location = new System.Drawing.Point(10, 48);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Size = new System.Drawing.Size(1511, 977);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "Channels";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.textBox22);
            this.groupBox18.Controls.Add(this.label24);
            this.groupBox18.Controls.Add(this.button16);
            this.groupBox18.Location = new System.Drawing.Point(459, 663);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox18.Size = new System.Drawing.Size(437, 198);
            this.groupBox18.TabIndex = 5;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Get Teams";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(160, 41);
            this.textBox22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(252, 38);
            this.textBox22.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(16, 43);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(146, 32);
            this.label24.TabIndex = 1;
            this.label24.Text = "Channnel:";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(5, 98);
            this.button16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(424, 81);
            this.button16.TabIndex = 0;
            this.button16.Text = "Fetch";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.textBox21);
            this.groupBox17.Controls.Add(this.label23);
            this.groupBox17.Controls.Add(this.textBox20);
            this.groupBox17.Controls.Add(this.label22);
            this.groupBox17.Controls.Add(this.button15);
            this.groupBox17.Location = new System.Drawing.Point(459, 398);
            this.groupBox17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox17.Size = new System.Drawing.Size(437, 248);
            this.groupBox17.TabIndex = 5;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Run Commercial";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(160, 98);
            this.textBox21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(252, 38);
            this.textBox21.TabIndex = 5;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(16, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(111, 32);
            this.label23.TabIndex = 4;
            this.label23.Text = "Length:";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(160, 41);
            this.textBox20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(252, 38);
            this.textBox20.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(16, 43);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(146, 32);
            this.label22.TabIndex = 1;
            this.label22.Text = "Channnel:";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(5, 150);
            this.button15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(424, 81);
            this.button15.TabIndex = 0;
            this.button15.Text = "Fetch";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.textBox19);
            this.groupBox16.Controls.Add(this.label21);
            this.groupBox16.Controls.Add(this.button14);
            this.groupBox16.Location = new System.Drawing.Point(459, 181);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox16.Size = new System.Drawing.Size(437, 198);
            this.groupBox16.TabIndex = 4;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Reset Stream Key";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(160, 41);
            this.textBox19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(252, 38);
            this.textBox19.TabIndex = 3;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(16, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(146, 32);
            this.label21.TabIndex = 1;
            this.label21.Text = "Channnel:";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(5, 98);
            this.button14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(424, 81);
            this.button14.TabIndex = 0;
            this.button14.Text = "Fetch";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.textBox18);
            this.groupBox15.Controls.Add(this.label20);
            this.groupBox15.Controls.Add(this.comboBox1);
            this.groupBox15.Controls.Add(this.textBox17);
            this.groupBox15.Controls.Add(this.textBox16);
            this.groupBox15.Controls.Add(this.label19);
            this.groupBox15.Controls.Add(this.label18);
            this.groupBox15.Controls.Add(this.label17);
            this.groupBox15.Controls.Add(this.textBox15);
            this.groupBox15.Controls.Add(this.label16);
            this.groupBox15.Controls.Add(this.button13);
            this.groupBox15.Location = new System.Drawing.Point(11, 429);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox15.Size = new System.Drawing.Size(437, 396);
            this.groupBox15.TabIndex = 5;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Update Channel";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(160, 196);
            this.textBox18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(252, 38);
            this.textBox18.TabIndex = 10;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 200);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 32);
            this.label20.TabIndex = 9;
            this.label20.Text = "Delay:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "No Change",
            "Enable",
            "Disable"});
            this.comboBox1.Location = new System.Drawing.Point(232, 267);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(185, 39);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.Text = "No Change";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(160, 143);
            this.textBox17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(252, 38);
            this.textBox17.TabIndex = 8;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(160, 95);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(252, 38);
            this.textBox16.TabIndex = 7;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(24, 272);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(202, 32);
            this.label19.TabIndex = 6;
            this.label19.Text = "Channel Feed:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(16, 150);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 32);
            this.label18.TabIndex = 5;
            this.label18.Text = "Game:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(16, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(104, 32);
            this.label17.TabIndex = 4;
            this.label17.Text = "Status:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(160, 41);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(252, 38);
            this.textBox15.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 43);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(146, 32);
            this.label16.TabIndex = 1;
            this.label16.Text = "Channnel:";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(11, 310);
            this.button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(424, 81);
            this.button13.TabIndex = 0;
            this.button13.Text = "Fetch";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button12);
            this.groupBox14.Location = new System.Drawing.Point(459, 21);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox14.Size = new System.Drawing.Size(437, 141);
            this.groupBox14.TabIndex = 5;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Get Channel using OAUTH";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(5, 43);
            this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(424, 81);
            this.button12.TabIndex = 0;
            this.button12.Text = "Fetch";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.textBox14);
            this.groupBox13.Controls.Add(this.label15);
            this.groupBox13.Controls.Add(this.button11);
            this.groupBox13.Location = new System.Drawing.Point(5, 224);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox13.Size = new System.Drawing.Size(437, 198);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Get Channel Editors";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(160, 41);
            this.textBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(252, 38);
            this.textBox14.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 43);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 32);
            this.label15.TabIndex = 1;
            this.label15.Text = "Channnel:";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(5, 98);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(424, 81);
            this.button11.TabIndex = 0;
            this.button11.Text = "Fetch";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.textBox13);
            this.groupBox12.Controls.Add(this.label14);
            this.groupBox12.Controls.Add(this.button10);
            this.groupBox12.Location = new System.Drawing.Point(5, 21);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox12.Size = new System.Drawing.Size(437, 198);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Get Channel";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(160, 41);
            this.textBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(252, 38);
            this.textBox13.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(146, 32);
            this.label14.TabIndex = 1;
            this.label14.Text = "Channnel:";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(5, 98);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(424, 81);
            this.button10.TabIndex = 0;
            this.button10.Text = "Fetch";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.groupBox21);
            this.tabPage8.Controls.Add(this.groupBox20);
            this.tabPage8.Controls.Add(this.groupBox19);
            this.tabPage8.Location = new System.Drawing.Point(10, 48);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage8.Size = new System.Drawing.Size(1511, 977);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "Chat";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.textBox24);
            this.groupBox21.Controls.Add(this.label26);
            this.groupBox21.Controls.Add(this.button19);
            this.groupBox21.Location = new System.Drawing.Point(16, 367);
            this.groupBox21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox21.Size = new System.Drawing.Size(437, 198);
            this.groupBox21.TabIndex = 5;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Get Emotes by Sets";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(216, 41);
            this.textBox24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(196, 38);
            this.textBox24.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(16, 43);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(203, 32);
            this.label26.TabIndex = 1;
            this.label26.Text = "Sets (sep by ,):";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(5, 98);
            this.button19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(424, 81);
            this.button19.TabIndex = 0;
            this.button19.Text = "Fetch";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.button18);
            this.groupBox20.Location = new System.Drawing.Point(16, 224);
            this.groupBox20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox20.Size = new System.Drawing.Size(437, 136);
            this.groupBox20.TabIndex = 5;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Get All Emoticons";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(5, 38);
            this.button18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(424, 81);
            this.button18.TabIndex = 0;
            this.button18.Text = "Fetch";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.textBox23);
            this.groupBox19.Controls.Add(this.label25);
            this.groupBox19.Controls.Add(this.button17);
            this.groupBox19.Location = new System.Drawing.Point(16, 19);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox19.Size = new System.Drawing.Size(437, 198);
            this.groupBox19.TabIndex = 4;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Get Badges by Channel";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(168, 41);
            this.textBox23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(247, 38);
            this.textBox23.TabIndex = 3;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 43);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(146, 32);
            this.label25.TabIndex = 1;
            this.label25.Text = "Channnel:";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(5, 98);
            this.button17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(424, 81);
            this.button17.TabIndex = 0;
            this.button17.Text = "Fetch";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.groupBox29);
            this.tabPage9.Controls.Add(this.groupBox28);
            this.tabPage9.Controls.Add(this.groupBox27);
            this.tabPage9.Controls.Add(this.groupBox26);
            this.tabPage9.Controls.Add(this.groupBox25);
            this.tabPage9.Location = new System.Drawing.Point(10, 48);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage9.Size = new System.Drawing.Size(1511, 977);
            this.tabPage9.TabIndex = 4;
            this.tabPage9.Text = "Follows";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.textBox32);
            this.groupBox29.Controls.Add(this.label34);
            this.groupBox29.Controls.Add(this.textBox33);
            this.groupBox29.Controls.Add(this.label35);
            this.groupBox29.Controls.Add(this.button27);
            this.groupBox29.Location = new System.Drawing.Point(651, 310);
            this.groupBox29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox29.Size = new System.Drawing.Size(437, 262);
            this.groupBox29.TabIndex = 9;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Remove Follow";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(168, 48);
            this.textBox32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(247, 38);
            this.textBox32.TabIndex = 5;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(16, 50);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(82, 32);
            this.label34.TabIndex = 4;
            this.label34.Text = "User:";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(168, 105);
            this.textBox33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(247, 38);
            this.textBox33.TabIndex = 3;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(16, 110);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(146, 32);
            this.label35.TabIndex = 1;
            this.label35.Text = "Channnel:";
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(5, 165);
            this.button27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(424, 81);
            this.button27.TabIndex = 0;
            this.button27.Text = "Fetch";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.textBox30);
            this.groupBox28.Controls.Add(this.label32);
            this.groupBox28.Controls.Add(this.textBox31);
            this.groupBox28.Controls.Add(this.label33);
            this.groupBox28.Controls.Add(this.button26);
            this.groupBox28.Location = new System.Drawing.Point(651, 21);
            this.groupBox28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox28.Size = new System.Drawing.Size(437, 262);
            this.groupBox28.TabIndex = 8;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Create Follow";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(168, 48);
            this.textBox30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(247, 38);
            this.textBox30.TabIndex = 5;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(16, 50);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(82, 32);
            this.label32.TabIndex = 4;
            this.label32.Text = "User:";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(168, 105);
            this.textBox31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(247, 38);
            this.textBox31.TabIndex = 3;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(16, 110);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(146, 32);
            this.label33.TabIndex = 1;
            this.label33.Text = "Channnel:";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(5, 165);
            this.button26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(424, 81);
            this.button26.TabIndex = 0;
            this.button26.Text = "Fetch";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.textBox29);
            this.groupBox27.Controls.Add(this.label31);
            this.groupBox27.Controls.Add(this.textBox28);
            this.groupBox27.Controls.Add(this.label30);
            this.groupBox27.Controls.Add(this.button25);
            this.groupBox27.Location = new System.Drawing.Point(16, 441);
            this.groupBox27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox27.Size = new System.Drawing.Size(437, 262);
            this.groupBox27.TabIndex = 7;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Get Channel Follows";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(168, 48);
            this.textBox29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(247, 38);
            this.textBox29.TabIndex = 5;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(16, 50);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(82, 32);
            this.label31.TabIndex = 4;
            this.label31.Text = "User:";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(168, 105);
            this.textBox28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(247, 38);
            this.textBox28.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(16, 110);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(146, 32);
            this.label30.TabIndex = 1;
            this.label30.Text = "Channnel:";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(5, 165);
            this.button25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(424, 81);
            this.button25.TabIndex = 0;
            this.button25.Text = "Fetch";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.textBox27);
            this.groupBox26.Controls.Add(this.label29);
            this.groupBox26.Controls.Add(this.button24);
            this.groupBox26.Location = new System.Drawing.Point(16, 236);
            this.groupBox26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox26.Size = new System.Drawing.Size(437, 198);
            this.groupBox26.TabIndex = 6;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Get Channel Follows";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(168, 41);
            this.textBox27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(247, 38);
            this.textBox27.TabIndex = 3;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(16, 43);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(146, 32);
            this.label29.TabIndex = 1;
            this.label29.Text = "Channnel:";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(5, 98);
            this.button24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(424, 81);
            this.button24.TabIndex = 0;
            this.button24.Text = "Fetch";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.textBox26);
            this.groupBox25.Controls.Add(this.label28);
            this.groupBox25.Controls.Add(this.button23);
            this.groupBox25.Location = new System.Drawing.Point(16, 21);
            this.groupBox25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox25.Size = new System.Drawing.Size(437, 198);
            this.groupBox25.TabIndex = 5;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Get Channel Followers";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(168, 41);
            this.textBox26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(247, 38);
            this.textBox26.TabIndex = 3;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(16, 43);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(146, 32);
            this.label28.TabIndex = 1;
            this.label28.Text = "Channnel:";
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(5, 98);
            this.button23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(424, 81);
            this.button23.TabIndex = 0;
            this.button23.Text = "Fetch";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox30);
            this.tabPage10.Location = new System.Drawing.Point(10, 48);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage10.Size = new System.Drawing.Size(1511, 977);
            this.tabPage10.TabIndex = 5;
            this.tabPage10.Text = "Games";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.button28);
            this.groupBox30.Location = new System.Drawing.Point(16, 19);
            this.groupBox30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox30.Size = new System.Drawing.Size(437, 136);
            this.groupBox30.TabIndex = 6;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Get Top Games";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(5, 38);
            this.button28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(424, 81);
            this.button28.TabIndex = 0;
            this.button28.Text = "Fetch";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox31);
            this.tabPage11.Location = new System.Drawing.Point(10, 48);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage11.Size = new System.Drawing.Size(1511, 977);
            this.tabPage11.TabIndex = 6;
            this.tabPage11.Text = "Ingests";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.button29);
            this.groupBox31.Location = new System.Drawing.Point(21, 19);
            this.groupBox31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox31.Size = new System.Drawing.Size(437, 136);
            this.groupBox31.TabIndex = 7;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Get Twitch Ingest Servers";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(5, 38);
            this.button29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(424, 81);
            this.button29.TabIndex = 0;
            this.button29.Text = "Fetch";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.groupBox32);
            this.tabPage12.Location = new System.Drawing.Point(10, 48);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage12.Size = new System.Drawing.Size(1511, 977);
            this.tabPage12.TabIndex = 7;
            this.tabPage12.Text = "Root";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.button30);
            this.groupBox32.Location = new System.Drawing.Point(21, 21);
            this.groupBox32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox32.Size = new System.Drawing.Size(437, 136);
            this.groupBox32.TabIndex = 8;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Get Root Data";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(5, 38);
            this.button30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(424, 81);
            this.button30.TabIndex = 0;
            this.button30.Text = "Fetch";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.groupBox35);
            this.tabPage13.Controls.Add(this.groupBox34);
            this.tabPage13.Controls.Add(this.groupBox33);
            this.tabPage13.Location = new System.Drawing.Point(10, 48);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage13.Size = new System.Drawing.Size(1511, 977);
            this.tabPage13.TabIndex = 8;
            this.tabPage13.Text = "Search";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.textBox36);
            this.groupBox35.Controls.Add(this.label38);
            this.groupBox35.Controls.Add(this.button33);
            this.groupBox35.Location = new System.Drawing.Point(995, 19);
            this.groupBox35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox35.Size = new System.Drawing.Size(437, 198);
            this.groupBox35.TabIndex = 8;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "Search Games";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(168, 41);
            this.textBox36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(247, 38);
            this.textBox36.TabIndex = 3;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(16, 43);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(123, 32);
            this.label38.TabIndex = 1;
            this.label38.Text = "Queries:";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(5, 98);
            this.button33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(424, 81);
            this.button33.TabIndex = 0;
            this.button33.Text = "Fetch";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.textBox35);
            this.groupBox34.Controls.Add(this.label37);
            this.groupBox34.Controls.Add(this.button32);
            this.groupBox34.Location = new System.Drawing.Point(496, 19);
            this.groupBox34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox34.Size = new System.Drawing.Size(437, 198);
            this.groupBox34.TabIndex = 7;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "Search Streams";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(168, 41);
            this.textBox35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(247, 38);
            this.textBox35.TabIndex = 3;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(16, 43);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(123, 32);
            this.label37.TabIndex = 1;
            this.label37.Text = "Queries:";
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(5, 98);
            this.button32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(424, 81);
            this.button32.TabIndex = 0;
            this.button32.Text = "Fetch";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.textBox34);
            this.groupBox33.Controls.Add(this.label36);
            this.groupBox33.Controls.Add(this.button31);
            this.groupBox33.Location = new System.Drawing.Point(21, 19);
            this.groupBox33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox33.Size = new System.Drawing.Size(437, 198);
            this.groupBox33.TabIndex = 6;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Search Channels";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(168, 41);
            this.textBox34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(247, 38);
            this.textBox34.TabIndex = 3;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(16, 43);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(123, 32);
            this.label36.TabIndex = 1;
            this.label36.Text = "Queries:";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(5, 98);
            this.button31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(424, 81);
            this.button31.TabIndex = 0;
            this.button31.Text = "Fetch";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.groupBox39);
            this.tabPage14.Controls.Add(this.groupBox38);
            this.tabPage14.Controls.Add(this.groupBox37);
            this.tabPage14.Controls.Add(this.groupBox36);
            this.tabPage14.Location = new System.Drawing.Point(10, 48);
            this.tabPage14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage14.Size = new System.Drawing.Size(1511, 977);
            this.tabPage14.TabIndex = 9;
            this.tabPage14.Text = "Streams";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.button37);
            this.groupBox39.Location = new System.Drawing.Point(16, 615);
            this.groupBox39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox39.Size = new System.Drawing.Size(437, 136);
            this.groupBox39.TabIndex = 10;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "Get Streams Summary";
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(5, 38);
            this.button37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(424, 81);
            this.button37.TabIndex = 0;
            this.button37.Text = "Fetch";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.button36);
            this.groupBox38.Location = new System.Drawing.Point(16, 451);
            this.groupBox38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox38.Size = new System.Drawing.Size(437, 136);
            this.groupBox38.TabIndex = 9;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "Get Featured Streams";
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(5, 38);
            this.button36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(424, 81);
            this.button36.TabIndex = 0;
            this.button36.Text = "Fetch";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.textBox38);
            this.groupBox37.Controls.Add(this.label40);
            this.groupBox37.Controls.Add(this.button35);
            this.groupBox37.Location = new System.Drawing.Point(16, 234);
            this.groupBox37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox37.Size = new System.Drawing.Size(437, 198);
            this.groupBox37.TabIndex = 8;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Get Streams";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(168, 41);
            this.textBox38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(247, 38);
            this.textBox38.TabIndex = 3;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(16, 43);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(100, 32);
            this.label40.TabIndex = 1;
            this.label40.Text = "Game:";
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(5, 98);
            this.button35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(424, 81);
            this.button35.TabIndex = 0;
            this.button35.Text = "Fetch";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.textBox37);
            this.groupBox36.Controls.Add(this.label39);
            this.groupBox36.Controls.Add(this.button34);
            this.groupBox36.Location = new System.Drawing.Point(16, 19);
            this.groupBox36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox36.Size = new System.Drawing.Size(437, 198);
            this.groupBox36.TabIndex = 7;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Get Stream";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(168, 41);
            this.textBox37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(247, 38);
            this.textBox37.TabIndex = 3;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(16, 43);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(130, 32);
            this.label39.TabIndex = 1;
            this.label39.Text = "Channel:";
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(5, 98);
            this.button34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(424, 81);
            this.button34.TabIndex = 0;
            this.button34.Text = "Fetch";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.groupBox44);
            this.tabPage15.Controls.Add(this.groupBox43);
            this.tabPage15.Controls.Add(this.groupBox42);
            this.tabPage15.Controls.Add(this.groupBox41);
            this.tabPage15.Controls.Add(this.groupBox40);
            this.tabPage15.Location = new System.Drawing.Point(10, 48);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage15.Size = new System.Drawing.Size(1511, 977);
            this.tabPage15.TabIndex = 10;
            this.tabPage15.Text = "Subscriptions";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.textBox45);
            this.groupBox44.Controls.Add(this.label47);
            this.groupBox44.Controls.Add(this.textBox44);
            this.groupBox44.Controls.Add(this.label46);
            this.groupBox44.Controls.Add(this.button42);
            this.groupBox44.Location = new System.Drawing.Point(477, 21);
            this.groupBox44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox44.Size = new System.Drawing.Size(437, 272);
            this.groupBox44.TabIndex = 9;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "User Subscribed to Channel";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(168, 98);
            this.textBox45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(247, 38);
            this.textBox45.TabIndex = 5;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(16, 100);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(130, 32);
            this.label47.TabIndex = 4;
            this.label47.Text = "Channel:";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(168, 41);
            this.textBox44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(247, 38);
            this.textBox44.TabIndex = 3;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(16, 43);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(89, 32);
            this.label46.TabIndex = 1;
            this.label46.Text = "User: ";
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(5, 165);
            this.button42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(424, 81);
            this.button42.TabIndex = 0;
            this.button42.Text = "Fetch";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.textBox43);
            this.groupBox43.Controls.Add(this.label45);
            this.groupBox43.Controls.Add(this.button41);
            this.groupBox43.Location = new System.Drawing.Point(19, 732);
            this.groupBox43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox43.Size = new System.Drawing.Size(437, 198);
            this.groupBox43.TabIndex = 9;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "Get Subscriber Count";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(168, 41);
            this.textBox43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(247, 38);
            this.textBox43.TabIndex = 3;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(16, 43);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(130, 32);
            this.label45.TabIndex = 1;
            this.label45.Text = "Channel:";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(5, 98);
            this.button41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(424, 81);
            this.button41.TabIndex = 0;
            this.button41.Text = "Fetch";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.textBox42);
            this.groupBox42.Controls.Add(this.label44);
            this.groupBox42.Controls.Add(this.textBox41);
            this.groupBox42.Controls.Add(this.label43);
            this.groupBox42.Controls.Add(this.button40);
            this.groupBox42.Location = new System.Drawing.Point(19, 458);
            this.groupBox42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox42.Size = new System.Drawing.Size(437, 267);
            this.groupBox42.TabIndex = 10;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Channel Has User Subscribed";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(168, 93);
            this.textBox42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(247, 38);
            this.textBox42.TabIndex = 5;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(16, 98);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(82, 32);
            this.label44.TabIndex = 4;
            this.label44.Text = "User:";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(168, 41);
            this.textBox41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(247, 38);
            this.textBox41.TabIndex = 3;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(16, 43);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(130, 32);
            this.label43.TabIndex = 1;
            this.label43.Text = "Channel:";
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(5, 167);
            this.button40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(424, 81);
            this.button40.TabIndex = 0;
            this.button40.Text = "Fetch";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.textBox40);
            this.groupBox41.Controls.Add(this.label42);
            this.groupBox41.Controls.Add(this.button39);
            this.groupBox41.Location = new System.Drawing.Point(19, 236);
            this.groupBox41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox41.Size = new System.Drawing.Size(437, 198);
            this.groupBox41.TabIndex = 9;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "Get All Subscribers";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(168, 41);
            this.textBox40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(247, 38);
            this.textBox40.TabIndex = 3;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(16, 43);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(130, 32);
            this.label42.TabIndex = 1;
            this.label42.Text = "Channel:";
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(5, 98);
            this.button39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(424, 81);
            this.button39.TabIndex = 0;
            this.button39.Text = "Fetch";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.textBox39);
            this.groupBox40.Controls.Add(this.label41);
            this.groupBox40.Controls.Add(this.button38);
            this.groupBox40.Location = new System.Drawing.Point(19, 21);
            this.groupBox40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox40.Size = new System.Drawing.Size(437, 198);
            this.groupBox40.TabIndex = 8;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "Get Subscribers";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(168, 41);
            this.textBox39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(247, 38);
            this.textBox39.TabIndex = 3;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(16, 43);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(130, 32);
            this.label41.TabIndex = 1;
            this.label41.Text = "Channel:";
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(5, 98);
            this.button38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(424, 81);
            this.button38.TabIndex = 0;
            this.button38.Text = "Fetch";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.groupBox46);
            this.tabPage16.Controls.Add(this.groupBox45);
            this.tabPage16.Location = new System.Drawing.Point(10, 48);
            this.tabPage16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage16.Size = new System.Drawing.Size(1511, 977);
            this.tabPage16.TabIndex = 11;
            this.tabPage16.Text = "Teams";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.textBox46);
            this.groupBox46.Controls.Add(this.label48);
            this.groupBox46.Controls.Add(this.button44);
            this.groupBox46.Location = new System.Drawing.Point(11, 160);
            this.groupBox46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox46.Size = new System.Drawing.Size(437, 198);
            this.groupBox46.TabIndex = 11;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Get Specific Team";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(168, 41);
            this.textBox46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(247, 38);
            this.textBox46.TabIndex = 3;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(16, 43);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(95, 32);
            this.label48.TabIndex = 1;
            this.label48.Text = "Team:";
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(5, 98);
            this.button44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(424, 81);
            this.button44.TabIndex = 0;
            this.button44.Text = "Fetch";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.button43);
            this.groupBox45.Location = new System.Drawing.Point(19, 17);
            this.groupBox45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox45.Size = new System.Drawing.Size(437, 136);
            this.groupBox45.TabIndex = 10;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Get Teams";
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(5, 38);
            this.button43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(424, 81);
            this.button43.TabIndex = 0;
            this.button43.Text = "Fetch";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.groupBox51);
            this.tabPage17.Controls.Add(this.groupBox50);
            this.tabPage17.Controls.Add(this.groupBox49);
            this.tabPage17.Controls.Add(this.groupBox48);
            this.tabPage17.Controls.Add(this.groupBox47);
            this.tabPage17.Location = new System.Drawing.Point(10, 48);
            this.tabPage17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage17.Size = new System.Drawing.Size(1511, 977);
            this.tabPage17.TabIndex = 12;
            this.tabPage17.Text = "User";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.button49);
            this.groupBox51.Location = new System.Drawing.Point(21, 758);
            this.groupBox51.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox51.Size = new System.Drawing.Size(437, 136);
            this.groupBox51.TabIndex = 16;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "Get Followed Videos";
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(5, 38);
            this.button49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(424, 81);
            this.button49.TabIndex = 0;
            this.button49.Text = "Fetch";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.button48);
            this.groupBox50.Location = new System.Drawing.Point(21, 601);
            this.groupBox50.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox50.Size = new System.Drawing.Size(437, 136);
            this.groupBox50.TabIndex = 15;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "Get Followed Streams";
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(5, 38);
            this.button48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(424, 81);
            this.button48.TabIndex = 0;
            this.button48.Text = "Fetch";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.button47);
            this.groupBox49.Location = new System.Drawing.Point(21, 446);
            this.groupBox49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox49.Size = new System.Drawing.Size(437, 136);
            this.groupBox49.TabIndex = 14;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Get User from Token";
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(5, 38);
            this.button47.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(424, 81);
            this.button47.TabIndex = 0;
            this.button47.Text = "Fetch";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.textBox48);
            this.groupBox48.Controls.Add(this.label50);
            this.groupBox48.Controls.Add(this.button46);
            this.groupBox48.Location = new System.Drawing.Point(21, 231);
            this.groupBox48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox48.Size = new System.Drawing.Size(437, 198);
            this.groupBox48.TabIndex = 13;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "Get Emotes";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(168, 41);
            this.textBox48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(247, 38);
            this.textBox48.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(16, 43);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(82, 32);
            this.label50.TabIndex = 1;
            this.label50.Text = "User:";
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(5, 98);
            this.button46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(424, 81);
            this.button46.TabIndex = 0;
            this.button46.Text = "Fetch";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.textBox47);
            this.groupBox47.Controls.Add(this.label49);
            this.groupBox47.Controls.Add(this.button45);
            this.groupBox47.Location = new System.Drawing.Point(21, 17);
            this.groupBox47.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox47.Size = new System.Drawing.Size(437, 198);
            this.groupBox47.TabIndex = 12;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "Get User";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(168, 41);
            this.textBox47.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(247, 38);
            this.textBox47.TabIndex = 3;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(16, 43);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(82, 32);
            this.label49.TabIndex = 1;
            this.label49.Text = "User:";
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(5, 98);
            this.button45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(424, 81);
            this.button45.TabIndex = 0;
            this.button45.Text = "Fetch";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.groupBox53);
            this.tabPage18.Controls.Add(this.groupBox52);
            this.tabPage18.Location = new System.Drawing.Point(10, 48);
            this.tabPage18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage18.Size = new System.Drawing.Size(1511, 977);
            this.tabPage18.TabIndex = 13;
            this.tabPage18.Text = "Videos";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // groupBox53
            // 
            this.groupBox53.Controls.Add(this.button51);
            this.groupBox53.Location = new System.Drawing.Point(16, 250);
            this.groupBox53.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox53.Size = new System.Drawing.Size(437, 136);
            this.groupBox53.TabIndex = 16;
            this.groupBox53.TabStop = false;
            this.groupBox53.Text = "Get Top Videos";
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(5, 38);
            this.button51.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(424, 81);
            this.button51.TabIndex = 0;
            this.button51.Text = "Fetch";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.textBox49);
            this.groupBox52.Controls.Add(this.label51);
            this.groupBox52.Controls.Add(this.button50);
            this.groupBox52.Location = new System.Drawing.Point(24, 24);
            this.groupBox52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox52.Size = new System.Drawing.Size(437, 198);
            this.groupBox52.TabIndex = 13;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Get Video";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(168, 41);
            this.textBox49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(247, 38);
            this.textBox49.TabIndex = 3;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(16, 43);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(127, 32);
            this.label51.TabIndex = 1;
            this.label51.Text = "Video Id:";
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(5, 98);
            this.button50.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(424, 81);
            this.button50.TabIndex = 0;
            this.button50.Text = "Fetch";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(187, 174);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(343, 38);
            this.textBox3.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(77, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "Token:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(421, 298);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(107, 32);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Update";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage37);
            this.tabControl2.Controls.Add(this.tabPage19);
            this.tabControl2.Controls.Add(this.tabPage21);
            this.tabControl2.Controls.Add(this.tabPage20);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Location = new System.Drawing.Point(11, 12);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1563, 1104);
            this.tabControl2.TabIndex = 2;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl1);
            this.tabPage3.Location = new System.Drawing.Point(10, 48);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "v3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tabControl3);
            this.tabPage7.Location = new System.Drawing.Point(10, 48);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage7.TabIndex = 3;
            this.tabPage7.Text = "v5";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage22);
            this.tabControl3.Controls.Add(this.tabPage23);
            this.tabControl3.Controls.Add(this.tabPage24);
            this.tabControl3.Controls.Add(this.tabPage25);
            this.tabControl3.Controls.Add(this.tabPage26);
            this.tabControl3.Controls.Add(this.tabPage27);
            this.tabControl3.Controls.Add(this.tabPage28);
            this.tabControl3.Controls.Add(this.tabPage29);
            this.tabControl3.Controls.Add(this.tabPage30);
            this.tabControl3.Controls.Add(this.tabPage31);
            this.tabControl3.Controls.Add(this.tabPage32);
            this.tabControl3.Controls.Add(this.tabPage33);
            this.tabControl3.Controls.Add(this.tabPage34);
            this.tabControl3.Controls.Add(this.tabPage35);
            this.tabControl3.Controls.Add(this.tabPage36);
            this.tabControl3.Location = new System.Drawing.Point(19, 19);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1496, 999);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage22
            // 
            this.tabPage22.Location = new System.Drawing.Point(10, 48);
            this.tabPage22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage22.Size = new System.Drawing.Size(1476, 941);
            this.tabPage22.TabIndex = 0;
            this.tabPage22.Text = "Root";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.groupBox73);
            this.tabPage23.Location = new System.Drawing.Point(10, 48);
            this.tabPage23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage23.Size = new System.Drawing.Size(1476, 941);
            this.tabPage23.TabIndex = 1;
            this.tabPage23.Text = "Bits";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // groupBox73
            // 
            this.groupBox73.Controls.Add(this.textBox71);
            this.groupBox73.Controls.Add(this.label74);
            this.groupBox73.Controls.Add(this.button74);
            this.groupBox73.Location = new System.Drawing.Point(19, 19);
            this.groupBox73.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox73.Name = "groupBox73";
            this.groupBox73.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox73.Size = new System.Drawing.Size(437, 198);
            this.groupBox73.TabIndex = 6;
            this.groupBox73.TabStop = false;
            this.groupBox73.Text = "GetCheermotes";
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(179, 43);
            this.textBox71.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(244, 38);
            this.textBox71.TabIndex = 2;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(5, 48);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(160, 32);
            this.label74.TabIndex = 1;
            this.label74.Text = "Channel Id:";
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(5, 100);
            this.button74.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(424, 81);
            this.button74.TabIndex = 0;
            this.button74.Text = "Send";
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // tabPage24
            // 
            this.tabPage24.Location = new System.Drawing.Point(10, 48);
            this.tabPage24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Size = new System.Drawing.Size(1476, 941);
            this.tabPage24.TabIndex = 2;
            this.tabPage24.Text = "ChannelFeed";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.groupBox74);
            this.tabPage25.Controls.Add(this.groupBox72);
            this.tabPage25.Controls.Add(this.groupBox71);
            this.tabPage25.Location = new System.Drawing.Point(10, 48);
            this.tabPage25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Size = new System.Drawing.Size(1476, 941);
            this.tabPage25.TabIndex = 3;
            this.tabPage25.Text = "Channels";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // groupBox74
            // 
            this.groupBox74.Controls.Add(this.textBox72);
            this.groupBox74.Controls.Add(this.label75);
            this.groupBox74.Controls.Add(this.button75);
            this.groupBox74.Location = new System.Drawing.Point(13, 444);
            this.groupBox74.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox74.Name = "groupBox74";
            this.groupBox74.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox74.Size = new System.Drawing.Size(437, 198);
            this.groupBox74.TabIndex = 6;
            this.groupBox74.TabStop = false;
            this.groupBox74.Text = "Get Channel Communities";
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(179, 41);
            this.textBox72.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(233, 38);
            this.textBox72.TabIndex = 3;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(16, 43);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(160, 32);
            this.label75.TabIndex = 1;
            this.label75.Text = "Channel Id:";
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(5, 98);
            this.button75.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(424, 81);
            this.button75.TabIndex = 0;
            this.button75.Text = "Fetch";
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // groupBox72
            // 
            this.groupBox72.Controls.Add(this.textBox70);
            this.groupBox72.Controls.Add(this.label73);
            this.groupBox72.Controls.Add(this.button73);
            this.groupBox72.Location = new System.Drawing.Point(13, 241);
            this.groupBox72.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox72.Name = "groupBox72";
            this.groupBox72.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox72.Size = new System.Drawing.Size(437, 198);
            this.groupBox72.TabIndex = 5;
            this.groupBox72.TabStop = false;
            this.groupBox72.Text = "Get Channel";
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(179, 43);
            this.textBox70.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(244, 38);
            this.textBox70.TabIndex = 2;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(5, 48);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(160, 32);
            this.label73.TabIndex = 1;
            this.label73.Text = "Channel Id:";
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(5, 100);
            this.button73.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(424, 81);
            this.button73.TabIndex = 0;
            this.button73.Text = "Send";
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // groupBox71
            // 
            this.groupBox71.Controls.Add(this.textBox69);
            this.groupBox71.Controls.Add(this.label72);
            this.groupBox71.Controls.Add(this.button72);
            this.groupBox71.Location = new System.Drawing.Point(13, 21);
            this.groupBox71.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox71.Name = "groupBox71";
            this.groupBox71.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox71.Size = new System.Drawing.Size(437, 198);
            this.groupBox71.TabIndex = 4;
            this.groupBox71.TabStop = false;
            this.groupBox71.Text = "Get All Channel Followers";
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(179, 43);
            this.textBox69.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(244, 38);
            this.textBox69.TabIndex = 2;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(5, 48);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(160, 32);
            this.label72.TabIndex = 1;
            this.label72.Text = "Channel Id:";
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(5, 100);
            this.button72.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(424, 81);
            this.button72.TabIndex = 0;
            this.button72.Text = "Send";
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // tabPage26
            // 
            this.tabPage26.Location = new System.Drawing.Point(10, 48);
            this.tabPage26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Size = new System.Drawing.Size(1476, 941);
            this.tabPage26.TabIndex = 4;
            this.tabPage26.Text = "Chat";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // tabPage27
            // 
            this.tabPage27.Location = new System.Drawing.Point(10, 48);
            this.tabPage27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Size = new System.Drawing.Size(1476, 941);
            this.tabPage27.TabIndex = 5;
            this.tabPage27.Text = "Collections";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // tabPage28
            // 
            this.tabPage28.Location = new System.Drawing.Point(10, 48);
            this.tabPage28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Size = new System.Drawing.Size(1476, 941);
            this.tabPage28.TabIndex = 6;
            this.tabPage28.Text = "Communities";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // tabPage29
            // 
            this.tabPage29.Location = new System.Drawing.Point(10, 48);
            this.tabPage29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Size = new System.Drawing.Size(1476, 941);
            this.tabPage29.TabIndex = 7;
            this.tabPage29.Text = "Games";
            this.tabPage29.UseVisualStyleBackColor = true;
            // 
            // tabPage30
            // 
            this.tabPage30.Location = new System.Drawing.Point(10, 48);
            this.tabPage30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Size = new System.Drawing.Size(1476, 941);
            this.tabPage30.TabIndex = 8;
            this.tabPage30.Text = "Ingests";
            this.tabPage30.UseVisualStyleBackColor = true;
            // 
            // tabPage31
            // 
            this.tabPage31.Location = new System.Drawing.Point(10, 48);
            this.tabPage31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Size = new System.Drawing.Size(1476, 941);
            this.tabPage31.TabIndex = 9;
            this.tabPage31.Text = "Search";
            this.tabPage31.UseVisualStyleBackColor = true;
            // 
            // tabPage32
            // 
            this.tabPage32.Controls.Add(this.groupBox75);
            this.tabPage32.Controls.Add(this.groupBox65);
            this.tabPage32.Location = new System.Drawing.Point(10, 48);
            this.tabPage32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Size = new System.Drawing.Size(1476, 941);
            this.tabPage32.TabIndex = 10;
            this.tabPage32.Text = "Streams";
            this.tabPage32.UseVisualStyleBackColor = true;
            // 
            // groupBox75
            // 
            this.groupBox75.Controls.Add(this.textBox73);
            this.groupBox75.Controls.Add(this.label76);
            this.groupBox75.Controls.Add(this.button76);
            this.groupBox75.Location = new System.Drawing.Point(19, 229);
            this.groupBox75.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox75.Name = "groupBox75";
            this.groupBox75.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox75.Size = new System.Drawing.Size(437, 198);
            this.groupBox75.TabIndex = 4;
            this.groupBox75.TabStop = false;
            this.groupBox75.Text = "Get Stream";
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(179, 43);
            this.textBox73.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(244, 38);
            this.textBox73.TabIndex = 2;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(5, 48);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(160, 32);
            this.label76.TabIndex = 1;
            this.label76.Text = "Channel Id:";
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(5, 100);
            this.button76.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(424, 81);
            this.button76.TabIndex = 0;
            this.button76.Text = "Send";
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // groupBox65
            // 
            this.groupBox65.Controls.Add(this.textBox62);
            this.groupBox65.Controls.Add(this.label65);
            this.groupBox65.Controls.Add(this.button64);
            this.groupBox65.Location = new System.Drawing.Point(19, 17);
            this.groupBox65.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox65.Name = "groupBox65";
            this.groupBox65.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox65.Size = new System.Drawing.Size(437, 198);
            this.groupBox65.TabIndex = 3;
            this.groupBox65.TabStop = false;
            this.groupBox65.Text = "Broadcaster Online";
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(179, 43);
            this.textBox62.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(244, 38);
            this.textBox62.TabIndex = 2;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(5, 48);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(160, 32);
            this.label65.TabIndex = 1;
            this.label65.Text = "Channel Id:";
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(5, 100);
            this.button64.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(424, 81);
            this.button64.TabIndex = 0;
            this.button64.Text = "Send";
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // tabPage33
            // 
            this.tabPage33.Location = new System.Drawing.Point(10, 48);
            this.tabPage33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage33.Name = "tabPage33";
            this.tabPage33.Size = new System.Drawing.Size(1476, 941);
            this.tabPage33.TabIndex = 11;
            this.tabPage33.Text = "Teams";
            this.tabPage33.UseVisualStyleBackColor = true;
            // 
            // tabPage34
            // 
            this.tabPage34.Controls.Add(this.groupBox67);
            this.tabPage34.Controls.Add(this.groupBox66);
            this.tabPage34.Location = new System.Drawing.Point(10, 48);
            this.tabPage34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage34.Name = "tabPage34";
            this.tabPage34.Size = new System.Drawing.Size(1476, 941);
            this.tabPage34.TabIndex = 12;
            this.tabPage34.Text = "Users";
            this.tabPage34.UseVisualStyleBackColor = true;
            // 
            // groupBox67
            // 
            this.groupBox67.Controls.Add(this.textBox65);
            this.groupBox67.Controls.Add(this.label68);
            this.groupBox67.Controls.Add(this.textBox66);
            this.groupBox67.Controls.Add(this.label69);
            this.groupBox67.Controls.Add(this.button66);
            this.groupBox67.Location = new System.Drawing.Point(8, 281);
            this.groupBox67.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox67.Name = "groupBox67";
            this.groupBox67.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox67.Size = new System.Drawing.Size(437, 250);
            this.groupBox67.TabIndex = 7;
            this.groupBox67.TabStop = false;
            this.groupBox67.Text = "UserFollowsChannel";
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(197, 98);
            this.textBox65.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(217, 38);
            this.textBox65.TabIndex = 5;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(16, 100);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(160, 32);
            this.label68.TabIndex = 4;
            this.label68.Text = "Channel Id:";
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(197, 41);
            this.textBox66.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(217, 38);
            this.textBox66.TabIndex = 3;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(16, 43);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(112, 32);
            this.label69.TabIndex = 1;
            this.label69.Text = "User Id:";
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(5, 153);
            this.button66.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(424, 81);
            this.button66.TabIndex = 0;
            this.button66.Text = "Fetch";
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // groupBox66
            // 
            this.groupBox66.Controls.Add(this.textBox63);
            this.groupBox66.Controls.Add(this.label66);
            this.groupBox66.Controls.Add(this.textBox64);
            this.groupBox66.Controls.Add(this.label67);
            this.groupBox66.Controls.Add(this.button65);
            this.groupBox66.Location = new System.Drawing.Point(16, 12);
            this.groupBox66.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox66.Name = "groupBox66";
            this.groupBox66.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox66.Size = new System.Drawing.Size(437, 250);
            this.groupBox66.TabIndex = 6;
            this.groupBox66.TabStop = false;
            this.groupBox66.Text = "CheckUserFollowsByChannel";
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(197, 98);
            this.textBox63.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(217, 38);
            this.textBox63.TabIndex = 5;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(16, 100);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(160, 32);
            this.label66.TabIndex = 4;
            this.label66.Text = "Channel Id:";
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(197, 41);
            this.textBox64.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(217, 38);
            this.textBox64.TabIndex = 3;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(16, 43);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(112, 32);
            this.label67.TabIndex = 1;
            this.label67.Text = "User Id:";
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(5, 153);
            this.button65.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(424, 81);
            this.button65.TabIndex = 0;
            this.button65.Text = "Fetch";
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // tabPage35
            // 
            this.tabPage35.Controls.Add(this.groupBox55);
            this.tabPage35.Location = new System.Drawing.Point(10, 48);
            this.tabPage35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage35.Name = "tabPage35";
            this.tabPage35.Size = new System.Drawing.Size(1476, 941);
            this.tabPage35.TabIndex = 13;
            this.tabPage35.Text = "Videos";
            this.tabPage35.UseVisualStyleBackColor = true;
            // 
            // groupBox55
            // 
            this.groupBox55.Controls.Add(this.textBox55);
            this.groupBox55.Controls.Add(this.label57);
            this.groupBox55.Controls.Add(this.textBox54);
            this.groupBox55.Controls.Add(this.label56);
            this.groupBox55.Controls.Add(this.textBox53);
            this.groupBox55.Controls.Add(this.label55);
            this.groupBox55.Controls.Add(this.textBox52);
            this.groupBox55.Controls.Add(this.label54);
            this.groupBox55.Controls.Add(this.button54);
            this.groupBox55.Controls.Add(this.textBox51);
            this.groupBox55.Controls.Add(this.label53);
            this.groupBox55.Controls.Add(this.button53);
            this.groupBox55.Location = new System.Drawing.Point(13, 21);
            this.groupBox55.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox55.Name = "groupBox55";
            this.groupBox55.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox55.Size = new System.Drawing.Size(451, 515);
            this.groupBox55.TabIndex = 7;
            this.groupBox55.TabStop = false;
            this.groupBox55.Text = "Upload Video";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(187, 55);
            this.textBox55.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(244, 38);
            this.textBox55.TabIndex = 12;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(16, 55);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(130, 32);
            this.label57.TabIndex = 11;
            this.label57.Text = "Channel:";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(133, 312);
            this.textBox54.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(297, 38);
            this.textBox54.TabIndex = 10;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(16, 312);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(100, 32);
            this.label56.TabIndex = 9;
            this.label56.Text = "Game:";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(187, 253);
            this.textBox53.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(244, 38);
            this.textBox53.TabIndex = 8;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(16, 253);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(166, 32);
            this.label55.TabIndex = 7;
            this.label55.Text = "Description:";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(99, 186);
            this.textBox52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(332, 38);
            this.textBox52.TabIndex = 6;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(16, 188);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(78, 32);
            this.label54.TabIndex = 5;
            this.label54.Text = "Title:";
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(360, 117);
            this.button54.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(72, 52);
            this.button54.TabIndex = 4;
            this.button54.Text = "...";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(91, 119);
            this.textBox51.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(263, 38);
            this.textBox51.TabIndex = 3;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(16, 122);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(70, 32);
            this.label53.TabIndex = 1;
            this.label53.Text = "File:";
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(21, 415);
            this.button53.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(411, 81);
            this.button53.TabIndex = 0;
            this.button53.Text = "Fetch";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // tabPage36
            // 
            this.tabPage36.Controls.Add(this.groupBox24);
            this.tabPage36.Controls.Add(this.groupBox23);
            this.tabPage36.Controls.Add(this.groupBox22);
            this.tabPage36.Location = new System.Drawing.Point(10, 48);
            this.tabPage36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage36.Name = "tabPage36";
            this.tabPage36.Size = new System.Drawing.Size(1476, 941);
            this.tabPage36.TabIndex = 14;
            this.tabPage36.Text = "Clips";
            this.tabPage36.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.button22);
            this.groupBox24.Location = new System.Drawing.Point(19, 391);
            this.groupBox24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox24.Size = new System.Drawing.Size(437, 143);
            this.groupBox24.TabIndex = 10;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Get Followed Clips";
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(5, 43);
            this.button22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(424, 81);
            this.button22.TabIndex = 0;
            this.button22.Text = "Fetch";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click_1);
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.button21);
            this.groupBox23.Location = new System.Drawing.Point(19, 234);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox23.Size = new System.Drawing.Size(437, 143);
            this.groupBox23.TabIndex = 9;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Get Top Clips";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(5, 43);
            this.button21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(424, 81);
            this.button21.TabIndex = 0;
            this.button21.Text = "Fetch";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.textBox25);
            this.groupBox22.Controls.Add(this.label27);
            this.groupBox22.Controls.Add(this.button20);
            this.groupBox22.Location = new System.Drawing.Point(19, 17);
            this.groupBox22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox22.Size = new System.Drawing.Size(437, 198);
            this.groupBox22.TabIndex = 8;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Get Clip Information";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(168, 41);
            this.textBox25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(247, 38);
            this.textBox25.TabIndex = 3;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(16, 43);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(138, 32);
            this.label27.TabIndex = 1;
            this.label27.Text = "Clip Slug:";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(5, 98);
            this.button20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(424, 81);
            this.button20.TabIndex = 0;
            this.button20.Text = "Fetch";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // tabPage37
            // 
            this.tabPage37.Controls.Add(this.tabControl4);
            this.tabPage37.Location = new System.Drawing.Point(10, 48);
            this.tabPage37.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabPage37.Name = "tabPage37";
            this.tabPage37.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabPage37.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage37.TabIndex = 8;
            this.tabPage37.Text = "Helix";
            this.tabPage37.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage38);
            this.tabControl4.Controls.Add(this.tabPage39);
            this.tabControl4.Controls.Add(this.tabPage40);
            this.tabControl4.Controls.Add(this.tabPage41);
            this.tabControl4.Controls.Add(this.tabPage42);
            this.tabControl4.Controls.Add(this.tabPage43);
            this.tabControl4.Location = new System.Drawing.Point(16, 14);
            this.tabControl4.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1509, 1021);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage38
            // 
            this.tabPage38.Controls.Add(this.groupBox82);
            this.tabPage38.Controls.Add(this.groupBox81);
            this.tabPage38.Controls.Add(this.groupBox80);
            this.tabPage38.Location = new System.Drawing.Point(10, 48);
            this.tabPage38.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabPage38.Name = "tabPage38";
            this.tabPage38.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabPage38.Size = new System.Drawing.Size(1489, 963);
            this.tabPage38.TabIndex = 0;
            this.tabPage38.Text = "Users";
            this.tabPage38.UseVisualStyleBackColor = true;
            // 
            // groupBox82
            // 
            this.groupBox82.Controls.Add(this.button85);
            this.groupBox82.Controls.Add(this.richTextBox4);
            this.groupBox82.Location = new System.Drawing.Point(1040, 14);
            this.groupBox82.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox82.Name = "groupBox82";
            this.groupBox82.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox82.Size = new System.Drawing.Size(432, 272);
            this.groupBox82.TabIndex = 2;
            this.groupBox82.TabStop = false;
            this.groupBox82.Text = "Put Users";
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(16, 198);
            this.button85.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(400, 55);
            this.button85.TabIndex = 9;
            this.button85.Text = "Update Description";
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(16, 38);
            this.richTextBox4.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(393, 149);
            this.richTextBox4.TabIndex = 0;
            this.richTextBox4.Text = "";
            // 
            // groupBox81
            // 
            this.groupBox81.Controls.Add(this.button84);
            this.groupBox81.Controls.Add(this.textBox83);
            this.groupBox81.Controls.Add(this.label84);
            this.groupBox81.Controls.Add(this.textBox82);
            this.groupBox81.Controls.Add(this.label83);
            this.groupBox81.Location = new System.Drawing.Point(565, 14);
            this.groupBox81.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox81.Name = "groupBox81";
            this.groupBox81.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox81.Size = new System.Drawing.Size(459, 272);
            this.groupBox81.TabIndex = 1;
            this.groupBox81.TabStop = false;
            this.groupBox81.Text = "Get Users Follows";
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(24, 198);
            this.button84.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(413, 55);
            this.button84.TabIndex = 6;
            this.button84.Text = "Check";
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(277, 131);
            this.textBox83.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(153, 38);
            this.textBox83.TabIndex = 8;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(16, 138);
            this.label84.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(242, 32);
            this.label84.TabIndex = 7;
            this.label84.Text = "follows user #2 id:";
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(184, 52);
            this.textBox82.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(153, 38);
            this.textBox82.TabIndex = 6;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(16, 60);
            this.label83.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(147, 32);
            this.label83.TabIndex = 0;
            this.label83.Text = "user #1 id:";
            // 
            // groupBox80
            // 
            this.groupBox80.Controls.Add(this.button83);
            this.groupBox80.Controls.Add(this.button82);
            this.groupBox80.Controls.Add(this.textBox81);
            this.groupBox80.Controls.Add(this.textBox80);
            this.groupBox80.Controls.Add(this.label82);
            this.groupBox80.Controls.Add(this.label81);
            this.groupBox80.Location = new System.Drawing.Point(16, 14);
            this.groupBox80.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox80.Name = "groupBox80";
            this.groupBox80.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox80.Size = new System.Drawing.Size(533, 210);
            this.groupBox80.TabIndex = 0;
            this.groupBox80.TabStop = false;
            this.groupBox80.Text = "Get Users";
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(269, 138);
            this.button83.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(213, 55);
            this.button83.TabIndex = 5;
            this.button83.Text = "Get User";
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(24, 138);
            this.button82.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(213, 55);
            this.button82.TabIndex = 4;
            this.button82.Text = "Get User";
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(269, 76);
            this.textBox81.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(207, 38);
            this.textBox81.TabIndex = 3;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(24, 76);
            this.textBox80.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(207, 38);
            this.textBox80.TabIndex = 2;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(261, 38);
            this.label82.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(153, 32);
            this.label82.TabIndex = 1;
            this.label82.Text = "Username:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(16, 38);
            this.label81.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(116, 32);
            this.label81.TabIndex = 0;
            this.label81.Text = "User ID:";
            // 
            // tabPage39
            // 
            this.tabPage39.Controls.Add(this.groupBox86);
            this.tabPage39.Location = new System.Drawing.Point(10, 48);
            this.tabPage39.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabPage39.Name = "tabPage39";
            this.tabPage39.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.tabPage39.Size = new System.Drawing.Size(1489, 963);
            this.tabPage39.TabIndex = 1;
            this.tabPage39.Text = "Streams";
            this.tabPage39.UseVisualStyleBackColor = true;
            // 
            // groupBox86
            // 
            this.groupBox86.Controls.Add(this.button89);
            this.groupBox86.Location = new System.Drawing.Point(16, 14);
            this.groupBox86.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox86.Name = "groupBox86";
            this.groupBox86.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox86.Size = new System.Drawing.Size(272, 148);
            this.groupBox86.TabIndex = 2;
            this.groupBox86.TabStop = false;
            this.groupBox86.Text = "Get Streams";
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(34, 56);
            this.button89.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(213, 55);
            this.button89.TabIndex = 5;
            this.button89.Text = "Get Game";
            this.button89.UseVisualStyleBackColor = true;
            this.button89.Click += new System.EventHandler(this.button89_Click);
            // 
            // tabPage40
            // 
            this.tabPage40.Controls.Add(this.groupBox83);
            this.tabPage40.Location = new System.Drawing.Point(10, 48);
            this.tabPage40.Name = "tabPage40";
            this.tabPage40.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage40.Size = new System.Drawing.Size(1489, 963);
            this.tabPage40.TabIndex = 2;
            this.tabPage40.Text = "Games";
            this.tabPage40.UseVisualStyleBackColor = true;
            // 
            // groupBox83
            // 
            this.groupBox83.Controls.Add(this.button86);
            this.groupBox83.Controls.Add(this.textBox84);
            this.groupBox83.Controls.Add(this.label85);
            this.groupBox83.Location = new System.Drawing.Point(11, 10);
            this.groupBox83.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox83.Name = "groupBox83";
            this.groupBox83.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox83.Size = new System.Drawing.Size(272, 210);
            this.groupBox83.TabIndex = 1;
            this.groupBox83.TabStop = false;
            this.groupBox83.Text = "Get Games";
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(33, 141);
            this.button86.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(213, 55);
            this.button86.TabIndex = 5;
            this.button86.Text = "Get Game";
            this.button86.UseVisualStyleBackColor = true;
            this.button86.Click += new System.EventHandler(this.button86_Click);
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(33, 79);
            this.textBox84.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(207, 38);
            this.textBox84.TabIndex = 3;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(25, 41);
            this.label85.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(98, 32);
            this.label85.TabIndex = 1;
            this.label85.Text = "Name:";
            // 
            // tabPage41
            // 
            this.tabPage41.Controls.Add(this.groupBox84);
            this.tabPage41.Location = new System.Drawing.Point(10, 48);
            this.tabPage41.Name = "tabPage41";
            this.tabPage41.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage41.Size = new System.Drawing.Size(1489, 963);
            this.tabPage41.TabIndex = 3;
            this.tabPage41.Text = "Videos";
            this.tabPage41.UseVisualStyleBackColor = true;
            // 
            // groupBox84
            // 
            this.groupBox84.Controls.Add(this.button87);
            this.groupBox84.Controls.Add(this.textBox85);
            this.groupBox84.Controls.Add(this.label86);
            this.groupBox84.Location = new System.Drawing.Point(11, 10);
            this.groupBox84.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox84.Name = "groupBox84";
            this.groupBox84.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox84.Size = new System.Drawing.Size(272, 210);
            this.groupBox84.TabIndex = 2;
            this.groupBox84.TabStop = false;
            this.groupBox84.Text = "Get Videos";
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(33, 141);
            this.button87.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(213, 55);
            this.button87.TabIndex = 5;
            this.button87.Text = "Get Videos";
            this.button87.UseVisualStyleBackColor = true;
            this.button87.Click += new System.EventHandler(this.button87_Click);
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(33, 79);
            this.textBox85.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(207, 38);
            this.textBox85.TabIndex = 3;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(25, 41);
            this.label86.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(127, 32);
            this.label86.TabIndex = 1;
            this.label86.Text = "Video id:";
            // 
            // tabPage42
            // 
            this.tabPage42.Controls.Add(this.groupBox89);
            this.tabPage42.Controls.Add(this.groupBox85);
            this.tabPage42.Location = new System.Drawing.Point(10, 48);
            this.tabPage42.Name = "tabPage42";
            this.tabPage42.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage42.Size = new System.Drawing.Size(1489, 963);
            this.tabPage42.TabIndex = 4;
            this.tabPage42.Text = "Webhooks";
            this.tabPage42.UseVisualStyleBackColor = true;
            // 
            // groupBox85
            // 
            this.groupBox85.Controls.Add(this.button88);
            this.groupBox85.Controls.Add(this.textBox87);
            this.groupBox85.Controls.Add(this.textBox86);
            this.groupBox85.Controls.Add(this.label88);
            this.groupBox85.Controls.Add(this.label87);
            this.groupBox85.Location = new System.Drawing.Point(6, 6);
            this.groupBox85.Name = "groupBox85";
            this.groupBox85.Size = new System.Drawing.Size(473, 228);
            this.groupBox85.TabIndex = 0;
            this.groupBox85.TabStop = false;
            this.groupBox85.Text = "User follows someone";
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(100, 152);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(353, 58);
            this.button88.TabIndex = 4;
            this.button88.Text = "Create Webhook";
            this.button88.UseVisualStyleBackColor = true;
            this.button88.Click += new System.EventHandler(this.button88_Click);
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(164, 96);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(289, 38);
            this.textBox87.TabIndex = 3;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(164, 47);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(289, 38);
            this.textBox86.TabIndex = 2;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(15, 102);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(133, 32);
            this.label88.TabIndex = 1;
            this.label88.Text = "Callback:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(15, 50);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(112, 32);
            this.label87.TabIndex = 0;
            this.label87.Text = "User id:";
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.groupBox79);
            this.tabPage19.Controls.Add(this.groupBox54);
            this.tabPage19.Location = new System.Drawing.Point(10, 48);
            this.tabPage19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage19.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage19.TabIndex = 4;
            this.tabPage19.Text = "ThirdParty";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // groupBox79
            // 
            this.groupBox79.Controls.Add(this.textBox79);
            this.groupBox79.Controls.Add(this.button81);
            this.groupBox79.Controls.Add(this.textBox78);
            this.groupBox79.Controls.Add(this.button80);
            this.groupBox79.Location = new System.Drawing.Point(504, 19);
            this.groupBox79.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox79.Name = "groupBox79";
            this.groupBox79.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox79.Size = new System.Drawing.Size(523, 157);
            this.groupBox79.TabIndex = 15;
            this.groupBox79.TabStop = false;
            this.groupBox79.Text = "TwitchTokenGenerator AuthFlow";
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(5, 93);
            this.textBox79.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(153, 38);
            this.textBox79.TabIndex = 5;
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(171, 93);
            this.button81.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(347, 50);
            this.button81.TabIndex = 4;
            this.button81.Text = "Monitor for Authorization";
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(240, 38);
            this.textBox78.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(271, 38);
            this.textBox78.TabIndex = 3;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(5, 38);
            this.button80.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(224, 50);
            this.button80.TabIndex = 0;
            this.button80.Text = "Get Auth Link";
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // groupBox54
            // 
            this.groupBox54.Controls.Add(this.textBox50);
            this.groupBox54.Controls.Add(this.label52);
            this.groupBox54.Controls.Add(this.button52);
            this.groupBox54.Location = new System.Drawing.Point(16, 19);
            this.groupBox54.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox54.Name = "groupBox54";
            this.groupBox54.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox54.Size = new System.Drawing.Size(437, 198);
            this.groupBox54.TabIndex = 14;
            this.groupBox54.TabStop = false;
            this.groupBox54.Text = "Get Username Changes";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(168, 41);
            this.textBox50.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(247, 38);
            this.textBox50.TabIndex = 3;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(16, 43);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(153, 32);
            this.label52.TabIndex = 1;
            this.label52.Text = "Username:";
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(5, 98);
            this.button52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(424, 81);
            this.button52.TabIndex = 0;
            this.button52.Text = "Fetch";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.groupBox78);
            this.tabPage21.Controls.Add(this.groupBox77);
            this.tabPage21.Controls.Add(this.groupBox76);
            this.tabPage21.Controls.Add(this.groupBox69);
            this.tabPage21.Controls.Add(this.groupBox64);
            this.tabPage21.Controls.Add(this.groupBox63);
            this.tabPage21.Controls.Add(this.groupBox62);
            this.tabPage21.Controls.Add(this.groupBox61);
            this.tabPage21.Controls.Add(this.groupBox60);
            this.tabPage21.Controls.Add(this.groupBox59);
            this.tabPage21.Controls.Add(this.groupBox58);
            this.tabPage21.Controls.Add(this.groupBox57);
            this.tabPage21.Location = new System.Drawing.Point(10, 48);
            this.tabPage21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage21.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage21.TabIndex = 6;
            this.tabPage21.Text = "Undocumented";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // groupBox78
            // 
            this.groupBox78.Controls.Add(this.textBox77);
            this.groupBox78.Controls.Add(this.label80);
            this.groupBox78.Controls.Add(this.button79);
            this.groupBox78.Location = new System.Drawing.Point(936, 646);
            this.groupBox78.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox78.Name = "groupBox78";
            this.groupBox78.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox78.Size = new System.Drawing.Size(437, 198);
            this.groupBox78.TabIndex = 12;
            this.groupBox78.TabStop = false;
            this.groupBox78.Text = "Get Mod Count";
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(232, 41);
            this.textBox77.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(180, 38);
            this.textBox77.TabIndex = 3;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(16, 43);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(153, 32);
            this.label80.TabIndex = 1;
            this.label80.Text = "Username:";
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(5, 98);
            this.button79.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(424, 81);
            this.button79.TabIndex = 0;
            this.button79.Text = "Fetch";
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // groupBox77
            // 
            this.groupBox77.Controls.Add(this.textBox76);
            this.groupBox77.Controls.Add(this.label79);
            this.groupBox77.Controls.Add(this.button78);
            this.groupBox77.Location = new System.Drawing.Point(936, 441);
            this.groupBox77.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox77.Name = "groupBox77";
            this.groupBox77.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox77.Size = new System.Drawing.Size(437, 198);
            this.groupBox77.TabIndex = 11;
            this.groupBox77.TabStop = false;
            this.groupBox77.Text = "Check if Username available";
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(232, 41);
            this.textBox76.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(180, 38);
            this.textBox76.TabIndex = 3;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(16, 43);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(153, 32);
            this.label79.TabIndex = 1;
            this.label79.Text = "Username:";
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(5, 98);
            this.button78.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(424, 81);
            this.button78.TabIndex = 0;
            this.button78.Text = "Fetch";
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // groupBox76
            // 
            this.groupBox76.Controls.Add(this.textBox75);
            this.groupBox76.Controls.Add(this.label78);
            this.groupBox76.Controls.Add(this.textBox74);
            this.groupBox76.Controls.Add(this.label77);
            this.groupBox76.Controls.Add(this.button77);
            this.groupBox76.Location = new System.Drawing.Point(483, 482);
            this.groupBox76.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox76.Name = "groupBox76";
            this.groupBox76.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox76.Size = new System.Drawing.Size(437, 253);
            this.groupBox76.TabIndex = 11;
            this.groupBox76.TabStop = false;
            this.groupBox76.Text = "Get Chatters";
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(232, 100);
            this.textBox75.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(180, 38);
            this.textBox75.TabIndex = 5;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(16, 107);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(160, 32);
            this.label78.TabIndex = 4;
            this.label78.Text = "Channel Id:";
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(232, 41);
            this.textBox74.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(180, 38);
            this.textBox74.TabIndex = 3;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(16, 43);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(116, 32);
            this.label77.TabIndex = 1;
            this.label77.Text = "User ID:";
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(5, 157);
            this.button77.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(424, 81);
            this.button77.TabIndex = 0;
            this.button77.Text = "Fetch";
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // groupBox69
            // 
            this.groupBox69.Controls.Add(this.button69);
            this.groupBox69.Location = new System.Drawing.Point(483, 324);
            this.groupBox69.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox69.Name = "groupBox69";
            this.groupBox69.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox69.Size = new System.Drawing.Size(437, 136);
            this.groupBox69.TabIndex = 10;
            this.groupBox69.TabStop = false;
            this.groupBox69.Text = "Get CS Streams";
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(5, 38);
            this.button69.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(424, 81);
            this.button69.TabIndex = 0;
            this.button69.Text = "Fetch";
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // groupBox64
            // 
            this.groupBox64.Controls.Add(this.textBox61);
            this.groupBox64.Controls.Add(this.label64);
            this.groupBox64.Controls.Add(this.button63);
            this.groupBox64.Location = new System.Drawing.Point(936, 227);
            this.groupBox64.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox64.Name = "groupBox64";
            this.groupBox64.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox64.Size = new System.Drawing.Size(437, 198);
            this.groupBox64.TabIndex = 10;
            this.groupBox64.TabStop = false;
            this.groupBox64.Text = "Get Chatters";
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(232, 41);
            this.textBox61.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(180, 38);
            this.textBox61.TabIndex = 3;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(16, 43);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(212, 32);
            this.label64.TabIndex = 1;
            this.label64.Text = "Channel Name:";
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(5, 98);
            this.button63.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(424, 81);
            this.button63.TabIndex = 0;
            this.button63.Text = "Fetch";
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // groupBox63
            // 
            this.groupBox63.Controls.Add(this.textBox60);
            this.groupBox63.Controls.Add(this.label63);
            this.groupBox63.Controls.Add(this.button62);
            this.groupBox63.Location = new System.Drawing.Point(936, 21);
            this.groupBox63.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox63.Name = "groupBox63";
            this.groupBox63.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox63.Size = new System.Drawing.Size(437, 198);
            this.groupBox63.TabIndex = 9;
            this.groupBox63.TabStop = false;
            this.groupBox63.Text = "Get Recent Messages";
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(184, 41);
            this.textBox60.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(228, 38);
            this.textBox60.TabIndex = 3;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(16, 43);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(164, 32);
            this.label63.TabIndex = 1;
            this.label63.Text = "CHannel Id:";
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(5, 98);
            this.button62.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(424, 81);
            this.button62.TabIndex = 0;
            this.button62.Text = "Fetch";
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // groupBox62
            // 
            this.groupBox62.Controls.Add(this.button61);
            this.groupBox62.Location = new System.Drawing.Point(483, 167);
            this.groupBox62.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox62.Name = "groupBox62";
            this.groupBox62.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox62.Size = new System.Drawing.Size(437, 136);
            this.groupBox62.TabIndex = 9;
            this.groupBox62.TabStop = false;
            this.groupBox62.Text = "Get CS Maps";
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(5, 38);
            this.button61.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(424, 81);
            this.button61.TabIndex = 0;
            this.button61.Text = "Fetch";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // groupBox61
            // 
            this.groupBox61.Controls.Add(this.textBox59);
            this.groupBox61.Controls.Add(this.label62);
            this.groupBox61.Controls.Add(this.button60);
            this.groupBox61.Location = new System.Drawing.Point(13, 646);
            this.groupBox61.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox61.Name = "groupBox61";
            this.groupBox61.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox61.Size = new System.Drawing.Size(437, 198);
            this.groupBox61.TabIndex = 10;
            this.groupBox61.TabStop = false;
            this.groupBox61.Text = "Get Channel Panels";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(232, 41);
            this.textBox59.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(180, 38);
            this.textBox59.TabIndex = 3;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(16, 43);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(212, 32);
            this.label62.TabIndex = 1;
            this.label62.Text = "Channel Name:";
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(5, 98);
            this.button60.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(424, 81);
            this.button60.TabIndex = 0;
            this.button60.Text = "Fetch";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // groupBox60
            // 
            this.groupBox60.Controls.Add(this.textBox58);
            this.groupBox60.Controls.Add(this.label61);
            this.groupBox60.Controls.Add(this.button59);
            this.groupBox60.Location = new System.Drawing.Point(13, 441);
            this.groupBox60.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox60.Name = "groupBox60";
            this.groupBox60.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox60.Size = new System.Drawing.Size(437, 198);
            this.groupBox60.TabIndex = 9;
            this.groupBox60.TabStop = false;
            this.groupBox60.Text = "Get Chat Properties";
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(232, 41);
            this.textBox58.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(180, 38);
            this.textBox58.TabIndex = 3;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(16, 43);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(212, 32);
            this.label61.TabIndex = 1;
            this.label61.Text = "Channel Name:";
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(5, 98);
            this.button59.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(424, 81);
            this.button59.TabIndex = 0;
            this.button59.Text = "Fetch";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // groupBox59
            // 
            this.groupBox59.Controls.Add(this.textBox57);
            this.groupBox59.Controls.Add(this.label60);
            this.groupBox59.Controls.Add(this.button58);
            this.groupBox59.Location = new System.Drawing.Point(19, 227);
            this.groupBox59.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox59.Name = "groupBox59";
            this.groupBox59.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox59.Size = new System.Drawing.Size(437, 198);
            this.groupBox59.TabIndex = 8;
            this.groupBox59.TabStop = false;
            this.groupBox59.Text = "Get Channel Hosts";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(184, 41);
            this.textBox57.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(228, 38);
            this.textBox57.TabIndex = 3;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(16, 43);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(164, 32);
            this.label60.TabIndex = 1;
            this.label60.Text = "CHannel Id:";
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(5, 98);
            this.button58.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(424, 81);
            this.button58.TabIndex = 0;
            this.button58.Text = "Fetch";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // groupBox58
            // 
            this.groupBox58.Controls.Add(this.button57);
            this.groupBox58.Location = new System.Drawing.Point(483, 21);
            this.groupBox58.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox58.Name = "groupBox58";
            this.groupBox58.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox58.Size = new System.Drawing.Size(437, 136);
            this.groupBox58.TabIndex = 8;
            this.groupBox58.TabStop = false;
            this.groupBox58.Text = "Get Twitch Prime Offers";
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(5, 38);
            this.button57.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(424, 81);
            this.button57.TabIndex = 0;
            this.button57.Text = "Fetch";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // groupBox57
            // 
            this.groupBox57.Controls.Add(this.textBox56);
            this.groupBox57.Controls.Add(this.label59);
            this.groupBox57.Controls.Add(this.button55);
            this.groupBox57.Location = new System.Drawing.Point(19, 21);
            this.groupBox57.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox57.Name = "groupBox57";
            this.groupBox57.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox57.Size = new System.Drawing.Size(437, 198);
            this.groupBox57.TabIndex = 7;
            this.groupBox57.TabStop = false;
            this.groupBox57.Text = "Get Clip Chat";
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(168, 41);
            this.textBox56.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(247, 38);
            this.textBox56.TabIndex = 3;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(16, 43);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(138, 32);
            this.label59.TabIndex = 1;
            this.label59.Text = "Clip Slug:";
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(5, 98);
            this.button55.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(424, 81);
            this.button55.TabIndex = 0;
            this.button55.Text = "Fetch";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.groupBox56);
            this.tabPage20.Location = new System.Drawing.Point(10, 48);
            this.tabPage20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage20.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage20.TabIndex = 5;
            this.tabPage20.Text = "Debugging";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // groupBox56
            // 
            this.groupBox56.Controls.Add(this.richTextBox3);
            this.groupBox56.Controls.Add(this.label58);
            this.groupBox56.Controls.Add(this.button56);
            this.groupBox56.Location = new System.Drawing.Point(19, 24);
            this.groupBox56.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox56.Name = "groupBox56";
            this.groupBox56.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox56.Size = new System.Drawing.Size(451, 515);
            this.groupBox56.TabIndex = 7;
            this.groupBox56.TabStop = false;
            this.groupBox56.Text = "Build Model";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(21, 83);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(409, 309);
            this.richTextBox3.TabIndex = 2;
            this.richTextBox3.Text = "";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(16, 50);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(83, 32);
            this.label58.TabIndex = 1;
            this.label58.Text = "Data:";
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(21, 415);
            this.button56.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(411, 81);
            this.button56.TabIndex = 0;
            this.button56.Text = "Fetch";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Location = new System.Drawing.Point(10, 48);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Settings";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.richTextBox1);
            this.groupBox5.Location = new System.Drawing.Point(685, 145);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(560, 353);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tips";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(24, 45);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(516, 283);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Location = new System.Drawing.Point(104, 136);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(560, 353);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(187, 229);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(343, 38);
            this.textBox6.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 32);
            this.label6.TabIndex = 6;
            this.label6.Text = "Channel ID";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox70);
            this.tabPage4.Controls.Add(this.groupBox68);
            this.tabPage4.Location = new System.Drawing.Point(10, 48);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Size = new System.Drawing.Size(1543, 1046);
            this.tabPage4.TabIndex = 7;
            this.tabPage4.Text = "Services";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox70
            // 
            this.groupBox70.Controls.Add(this.button70);
            this.groupBox70.Controls.Add(this.textBox68);
            this.groupBox70.Controls.Add(this.label71);
            this.groupBox70.Controls.Add(this.button71);
            this.groupBox70.Location = new System.Drawing.Point(19, 229);
            this.groupBox70.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox70.Name = "groupBox70";
            this.groupBox70.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox70.Size = new System.Drawing.Size(437, 198);
            this.groupBox70.TabIndex = 5;
            this.groupBox70.TabStop = false;
            this.groupBox70.Text = "FollowerService";
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(267, 98);
            this.button70.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(147, 81);
            this.button70.TabIndex = 4;
            this.button70.Text = "Stop";
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(173, 41);
            this.textBox68.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(239, 38);
            this.textBox68.TabIndex = 3;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(16, 43);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(153, 32);
            this.label71.TabIndex = 1;
            this.label71.Text = "ChannelId:";
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(5, 98);
            this.button71.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(147, 81);
            this.button71.TabIndex = 0;
            this.button71.Text = "Start";
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // groupBox68
            // 
            this.groupBox68.Controls.Add(this.button68);
            this.groupBox68.Controls.Add(this.textBox67);
            this.groupBox68.Controls.Add(this.label70);
            this.groupBox68.Controls.Add(this.button67);
            this.groupBox68.Location = new System.Drawing.Point(19, 17);
            this.groupBox68.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox68.Name = "groupBox68";
            this.groupBox68.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox68.Size = new System.Drawing.Size(437, 198);
            this.groupBox68.TabIndex = 3;
            this.groupBox68.TabStop = false;
            this.groupBox68.Text = "LiveStreamMonitor";
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(267, 98);
            this.button68.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(147, 81);
            this.button68.TabIndex = 4;
            this.button68.Text = "Stop";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(173, 41);
            this.textBox67.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(239, 38);
            this.textBox67.TabIndex = 3;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(16, 43);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(153, 32);
            this.label70.TabIndex = 1;
            this.label70.Text = "ChannelId:";
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(5, 98);
            this.button67.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(147, 81);
            this.button67.TabIndex = 0;
            this.button67.Text = "Start";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // tabPage43
            // 
            this.tabPage43.Controls.Add(this.groupBox88);
            this.tabPage43.Controls.Add(this.groupBox87);
            this.tabPage43.Location = new System.Drawing.Point(10, 48);
            this.tabPage43.Name = "tabPage43";
            this.tabPage43.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage43.Size = new System.Drawing.Size(1489, 963);
            this.tabPage43.TabIndex = 5;
            this.tabPage43.Text = "Clips";
            this.tabPage43.UseVisualStyleBackColor = true;
            // 
            // groupBox87
            // 
            this.groupBox87.Controls.Add(this.button90);
            this.groupBox87.Controls.Add(this.textBox88);
            this.groupBox87.Controls.Add(this.label89);
            this.groupBox87.Location = new System.Drawing.Point(11, 10);
            this.groupBox87.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox87.Name = "groupBox87";
            this.groupBox87.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox87.Size = new System.Drawing.Size(272, 210);
            this.groupBox87.TabIndex = 2;
            this.groupBox87.TabStop = false;
            this.groupBox87.Text = "Get Clip";
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(33, 141);
            this.button90.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(213, 55);
            this.button90.TabIndex = 5;
            this.button90.Text = "Get Clip";
            this.button90.UseVisualStyleBackColor = true;
            this.button90.Click += new System.EventHandler(this.button90_Click);
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(33, 79);
            this.textBox88.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(207, 38);
            this.textBox88.TabIndex = 3;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(25, 41);
            this.label89.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(99, 32);
            this.label89.TabIndex = 1;
            this.label89.Text = "Clip ID";
            // 
            // groupBox88
            // 
            this.groupBox88.Controls.Add(this.button91);
            this.groupBox88.Controls.Add(this.textBox89);
            this.groupBox88.Controls.Add(this.label90);
            this.groupBox88.Location = new System.Drawing.Point(299, 10);
            this.groupBox88.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox88.Name = "groupBox88";
            this.groupBox88.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBox88.Size = new System.Drawing.Size(272, 210);
            this.groupBox88.TabIndex = 6;
            this.groupBox88.TabStop = false;
            this.groupBox88.Text = "Create Clip";
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(33, 141);
            this.button91.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(213, 55);
            this.button91.TabIndex = 5;
            this.button91.Text = "Create Clip";
            this.button91.UseVisualStyleBackColor = true;
            this.button91.Click += new System.EventHandler(this.button91_Click);
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(33, 79);
            this.textBox89.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(207, 38);
            this.textBox89.TabIndex = 3;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(25, 41);
            this.label90.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(210, 32);
            this.label90.TabIndex = 1;
            this.label90.Text = "Broadcaster ID:";
            // 
            // groupBox89
            // 
            this.groupBox89.Controls.Add(this.button92);
            this.groupBox89.Controls.Add(this.textBox90);
            this.groupBox89.Controls.Add(this.textBox91);
            this.groupBox89.Controls.Add(this.label91);
            this.groupBox89.Controls.Add(this.label92);
            this.groupBox89.Location = new System.Drawing.Point(500, 6);
            this.groupBox89.Name = "groupBox89";
            this.groupBox89.Size = new System.Drawing.Size(473, 228);
            this.groupBox89.TabIndex = 5;
            this.groupBox89.TabStop = false;
            this.groupBox89.Text = "Stream Up or Down";
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(100, 152);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(353, 58);
            this.button92.TabIndex = 4;
            this.button92.Text = "Create Webhook";
            this.button92.UseVisualStyleBackColor = true;
            this.button92.Click += new System.EventHandler(this.button92_Click);
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(164, 96);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(289, 38);
            this.textBox90.TabIndex = 3;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(164, 47);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(289, 38);
            this.textBox91.TabIndex = 2;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(15, 102);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(133, 32);
            this.label91.TabIndex = 1;
            this.label91.Text = "Callback:";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(15, 50);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(112, 32);
            this.label92.TabIndex = 0;
            this.label92.Text = "User id:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1595, 1137);
            this.Controls.Add(this.tabControl2);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "TwitchLib API Tester";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.groupBox30.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.groupBox32.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.groupBox35.ResumeLayout(false);
            this.groupBox35.PerformLayout();
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.groupBox39.ResumeLayout(false);
            this.groupBox38.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox45.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.groupBox51.ResumeLayout(false);
            this.groupBox50.ResumeLayout(false);
            this.groupBox49.ResumeLayout(false);
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.groupBox47.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.groupBox53.ResumeLayout(false);
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.groupBox73.ResumeLayout(false);
            this.groupBox73.PerformLayout();
            this.tabPage25.ResumeLayout(false);
            this.groupBox74.ResumeLayout(false);
            this.groupBox74.PerformLayout();
            this.groupBox72.ResumeLayout(false);
            this.groupBox72.PerformLayout();
            this.groupBox71.ResumeLayout(false);
            this.groupBox71.PerformLayout();
            this.tabPage32.ResumeLayout(false);
            this.groupBox75.ResumeLayout(false);
            this.groupBox75.PerformLayout();
            this.groupBox65.ResumeLayout(false);
            this.groupBox65.PerformLayout();
            this.tabPage34.ResumeLayout(false);
            this.groupBox67.ResumeLayout(false);
            this.groupBox67.PerformLayout();
            this.groupBox66.ResumeLayout(false);
            this.groupBox66.PerformLayout();
            this.tabPage35.ResumeLayout(false);
            this.groupBox55.ResumeLayout(false);
            this.groupBox55.PerformLayout();
            this.tabPage36.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabPage37.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage38.ResumeLayout(false);
            this.groupBox82.ResumeLayout(false);
            this.groupBox81.ResumeLayout(false);
            this.groupBox81.PerformLayout();
            this.groupBox80.ResumeLayout(false);
            this.groupBox80.PerformLayout();
            this.tabPage39.ResumeLayout(false);
            this.groupBox86.ResumeLayout(false);
            this.tabPage40.ResumeLayout(false);
            this.groupBox83.ResumeLayout(false);
            this.groupBox83.PerformLayout();
            this.tabPage41.ResumeLayout(false);
            this.groupBox84.ResumeLayout(false);
            this.groupBox84.PerformLayout();
            this.tabPage42.ResumeLayout(false);
            this.groupBox85.ResumeLayout(false);
            this.groupBox85.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.groupBox79.ResumeLayout(false);
            this.groupBox79.PerformLayout();
            this.groupBox54.ResumeLayout(false);
            this.groupBox54.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.groupBox78.ResumeLayout(false);
            this.groupBox78.PerformLayout();
            this.groupBox77.ResumeLayout(false);
            this.groupBox77.PerformLayout();
            this.groupBox76.ResumeLayout(false);
            this.groupBox76.PerformLayout();
            this.groupBox69.ResumeLayout(false);
            this.groupBox64.ResumeLayout(false);
            this.groupBox64.PerformLayout();
            this.groupBox63.ResumeLayout(false);
            this.groupBox63.PerformLayout();
            this.groupBox62.ResumeLayout(false);
            this.groupBox61.ResumeLayout(false);
            this.groupBox61.PerformLayout();
            this.groupBox60.ResumeLayout(false);
            this.groupBox60.PerformLayout();
            this.groupBox59.ResumeLayout(false);
            this.groupBox59.PerformLayout();
            this.groupBox58.ResumeLayout(false);
            this.groupBox57.ResumeLayout(false);
            this.groupBox57.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.groupBox56.ResumeLayout(false);
            this.groupBox56.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox70.ResumeLayout(false);
            this.groupBox70.PerformLayout();
            this.groupBox68.ResumeLayout(false);
            this.groupBox68.PerformLayout();
            this.tabPage43.ResumeLayout(false);
            this.groupBox87.ResumeLayout(false);
            this.groupBox87.PerformLayout();
            this.groupBox88.ResumeLayout(false);
            this.groupBox88.PerformLayout();
            this.groupBox89.ResumeLayout(false);
            this.groupBox89.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.GroupBox groupBox53;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.GroupBox groupBox54;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.GroupBox groupBox56;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.GroupBox groupBox58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.GroupBox groupBox57;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.GroupBox groupBox59;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.GroupBox groupBox60;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.GroupBox groupBox61;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.GroupBox groupBox62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.GroupBox groupBox63;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.GroupBox groupBox64;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.TabPage tabPage32;
        private System.Windows.Forms.GroupBox groupBox65;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.TabPage tabPage33;
        private System.Windows.Forms.TabPage tabPage34;
        private System.Windows.Forms.TabPage tabPage35;
        private System.Windows.Forms.TabPage tabPage36;
        private System.Windows.Forms.GroupBox groupBox66;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.GroupBox groupBox67;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.GroupBox groupBox55;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox68;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.GroupBox groupBox69;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.GroupBox groupBox70;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.GroupBox groupBox71;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.GroupBox groupBox72;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.GroupBox groupBox73;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.GroupBox groupBox74;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.GroupBox groupBox75;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.GroupBox groupBox76;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.GroupBox groupBox77;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.GroupBox groupBox78;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.GroupBox groupBox79;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TabPage tabPage37;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage38;
        private System.Windows.Forms.TabPage tabPage39;
        private System.Windows.Forms.GroupBox groupBox80;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.GroupBox groupBox81;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.GroupBox groupBox82;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.TabPage tabPage40;
        private System.Windows.Forms.GroupBox groupBox83;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TabPage tabPage41;
        private System.Windows.Forms.GroupBox groupBox84;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TabPage tabPage42;
        private System.Windows.Forms.GroupBox groupBox85;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.GroupBox groupBox86;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.TabPage tabPage43;
        private System.Windows.Forms.GroupBox groupBox87;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.GroupBox groupBox88;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.GroupBox groupBox89;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
    }
}


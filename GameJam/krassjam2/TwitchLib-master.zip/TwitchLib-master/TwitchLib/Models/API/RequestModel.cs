﻿namespace TwitchLib.Models.API
{
    public abstract class RequestModel
    {

    }
}

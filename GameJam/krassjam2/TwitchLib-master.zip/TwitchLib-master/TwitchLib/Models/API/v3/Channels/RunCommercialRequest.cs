﻿namespace TwitchLib.Models.API.v3.Channels
{
    public class RunCommercialRequest : RequestModel
    {
        public int Length { get; set; }
    }
}

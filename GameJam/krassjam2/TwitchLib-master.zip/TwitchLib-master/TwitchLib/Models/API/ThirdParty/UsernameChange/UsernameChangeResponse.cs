﻿namespace TwitchLib.Models.API.ThirdParty.UsernameChange
{
    public class UsernameChangeResponse
    {
        public UsernameChangeListing[] UsernameChangeListings { get; protected set; }
    }
}

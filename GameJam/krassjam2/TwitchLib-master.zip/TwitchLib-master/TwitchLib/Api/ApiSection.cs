﻿namespace TwitchLib.Api
{
    public class ApiSection
    {
        protected TwitchAPI Api;

        public ApiSection(TwitchAPI api)
        {
            Api = api;
        }
    }
}

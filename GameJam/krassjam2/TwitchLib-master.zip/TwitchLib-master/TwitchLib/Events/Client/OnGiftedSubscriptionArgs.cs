﻿using System;
using System.Collections.Generic;
using System.Text;
using TwitchLib.Models.Client;

namespace TwitchLib.Events.Client
{
    public class OnGiftedSubscriptionArgs
    {
        public GiftedSubscription GiftedSubscription;
    }
}

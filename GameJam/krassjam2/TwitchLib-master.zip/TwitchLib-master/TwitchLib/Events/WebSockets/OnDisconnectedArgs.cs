﻿namespace TwitchLib.Events.WebSockets
{
    public class OnDisconnectedArgs
    {
        public string Reason { get; set; }
    }
}

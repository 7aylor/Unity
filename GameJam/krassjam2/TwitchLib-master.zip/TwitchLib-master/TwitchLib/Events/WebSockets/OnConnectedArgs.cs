﻿namespace TwitchLib.Events.WebSockets
{
    public class OnConnectedArgs
    {
        public string Url { get; set; }
    }
}

﻿using System;

namespace TwitchLib.Events.WebSockets
{
    public class OnErrorArgs
    {
        public Exception Exception { get; set;}
    }
}

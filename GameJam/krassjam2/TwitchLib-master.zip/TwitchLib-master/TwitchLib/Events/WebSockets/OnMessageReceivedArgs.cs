﻿namespace TwitchLib.Events.WebSockets
{
    public class OnMessageReceivedArgs
    {
        public string Message { get; set; }
    }
}

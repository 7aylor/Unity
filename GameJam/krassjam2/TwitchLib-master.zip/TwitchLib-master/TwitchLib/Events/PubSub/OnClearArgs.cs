﻿namespace TwitchLib.Events.PubSub
{
    /// <summary></summary>
    public class OnClearArgs
    {
        /// <summary>Property representing username of moderator who cleared chat.</summary>
        public string Moderator;
    }
}

﻿namespace TwitchLib.Events.PubSub
{
    #region using directives
    using Models.PubSub.Responses.Messages;
    #endregion
    /// <summary>[INCOMPLETE/NOT_FULLY_SUPPORTED]Whisper arguement class.</summary>
    public class OnWhisperArgs
    {
        /// <summary>Property representing the whisper object.</summary>
        public Whisper Whisper;
        /// <summary>Whisper args class constructor.</summary>
        public OnWhisperArgs() { }
    }
}

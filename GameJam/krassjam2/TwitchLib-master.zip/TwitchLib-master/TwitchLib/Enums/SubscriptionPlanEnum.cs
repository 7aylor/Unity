﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitchLib.Enums
{
    public enum SubscriptionPlan
    {
        NotSet,
        Prime,
        Tier1,
        Tier2,
        Tier3
    }
}

﻿namespace TwitchLib.Enums
{
    public enum Viewable
    {
        Public,
        Private
    }
}

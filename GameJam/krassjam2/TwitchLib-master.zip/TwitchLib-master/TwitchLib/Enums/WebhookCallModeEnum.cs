﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TwitchLib.Enums
{
    public enum WebhookCallMode
    {
        Subscribe,
        Unsubscribe
    }
}

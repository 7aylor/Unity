﻿namespace TwitchLib.Enums
{
    public enum SortBy
    {
        CreatedAt,
        LastBroadcast,
        Login
    }
}

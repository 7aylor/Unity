﻿namespace TwitchLib.Enums
{
    public enum Direction
    {
        Ascending,
        Descending
    }
}

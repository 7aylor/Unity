﻿namespace TwitchLib.Enums
{
    public enum BroadcastType
    {
        All, 
        Archive,
        Highlight
    }
}

﻿namespace TwitchLib.Enums
{
    public enum GameSearchType
    {
        Suggest
    }
}
